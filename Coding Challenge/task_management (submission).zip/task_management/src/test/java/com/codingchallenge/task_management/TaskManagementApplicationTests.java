package com.codingchallenge.task_management;

import com.codingchallenge.task_management.entity.Task;
import com.codingchallenge.task_management.repository.TaskRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class TaskManagementApplicationTests {

    @Autowired
    private TaskRepository taskRepository;

    @Test
    public void testCreateTask() {
        Task task = new Task();
        task.setTitle("Unit Test Task");
        task.setDescription("Test desc");
        task.setDueDate("2025-07-01");
        task.setPriority("High");
        task.setStatus("Pending");

        Task saved = taskRepository.save(task);
        assertNotNull(saved.getId());
        assertEquals("Unit Test Task", saved.getTitle());
    }

    @Test
    public void testGetTaskById() {
        Task task = new Task();
        task.setTitle("Get By ID Task");
        task.setDescription("Test get");
        task.setDueDate("2025-07-02");
        task.setPriority("Low");
        task.setStatus("Pending");

        Task saved = taskRepository.save(task);
        Optional<Task> found = taskRepository.findById(saved.getId());

        assertTrue(found.isPresent());
        assertEquals("Get By ID Task", found.get().getTitle());
    }

    @Test
    public void testGetAllTasks() {
        Task task1 = new Task();
        task1.setTitle("Task 1");
        task1.setDescription("Desc 1");
        task1.setDueDate("2025-07-03");
        task1.setPriority("Medium");
        task1.setStatus("In Progress");

        Task task2 = new Task();
        task2.setTitle("Task 2");
        task2.setDescription("Desc 2");
        task2.setDueDate("2025-07-04");
        task2.setPriority("High");
        task2.setStatus("Pending");

        taskRepository.save(task1);
        taskRepository.save(task2);

        List<Task> allTasks = taskRepository.findAll();
        assertFalse(allTasks.isEmpty());
        assertTrue(allTasks.size() >= 2);
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task();
        task.setTitle("Original Title");
        task.setDescription("Original Desc");
        task.setDueDate("2025-07-05");
        task.setPriority("Low");
        task.setStatus("Pending");

        Task saved = taskRepository.save(task);
        saved.setTitle("Updated Title");
        saved.setStatus("Completed");

        Task updated = taskRepository.save(saved);
        assertEquals("Updated Title", updated.getTitle());
        assertEquals("Completed", updated.getStatus());
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task();
        task.setTitle("To Be Deleted");
        task.setDescription("Will be deleted");
        task.setDueDate("2025-07-06");
        task.setPriority("Medium");
        task.setStatus("Pending");

        Task saved = taskRepository.save(task);
        Long id = saved.getId();

        taskRepository.deleteById(id);
        Optional<Task> deleted = taskRepository.findById(id);

        assertFalse(deleted.isPresent());
    }
}
