// src/App.js

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import EditJob from './components/EditJob';


import AppNavbar from './components/Navbar'; // ✅ Import the navbar

import Home from './components/Home';
import Login from './components/Login';
import Register from './components/Register';
import JobList from './components/JobList';
import PostJob from './components/PostJob';
import Applications from './components/Applications';
import Profile from './components/Profile';
import AdminHome from './components/AdminHome';
import UserHome from './components/UserHome';
import ResumeUpload from './components/ResumeUpload';
import JobDetails from './components/JobDetails';
import ProfileView from './components/ProfileView';
import MyPostedJobs from './components/MyPostedJobs';
import EmployerApplications from './components/ViewApplications';

function App() {
  return (
    <Router>
      {/* ✅ Navbar always visible */}
      <AppNavbar />

      <Routes>
        {/* ✅ Home is now the default route */}
        <Route path="/" element={<Home />} />
        
        {/* ✅ Login and Register are separate */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* ✅ Your other routes */}
        <Route path="/home" element={<Home />} />
        <Route path="/admin-home" element={<AdminHome />} />
        <Route path="/user-home" element={<UserHome />} />
        <Route path="/jobs" element={<JobList />} />
        <Route path="/job-details/:jobId" element={<JobDetails />} />
        <Route path="/post-job" element={<PostJob />} />
        <Route path="/applications" element={<Applications />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/profile/view" element={<ProfileView />} />
        <Route path="/resume" element={<ResumeUpload />} />
        <Route path="/my-posted-jobs" element={<MyPostedJobs />} />
        <Route path="/employer-applications" element={<EmployerApplications />} />
        <Route path="/edit-job/:id" element={<EditJob />} />
      </Routes>
    </Router>
  );
}

export default App;
