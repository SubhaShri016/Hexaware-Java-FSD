import React from 'react';
import { Link } from 'react-router-dom';

function AdminHome() {
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <div
      className="d-flex flex-column justify-content-center align-items-center text-center"
      style={{
        minHeight: '100vh',
        margin: 0,
        background: 'linear-gradient(135deg, #f5a25d, #1f2a48)', // Orange → Blue gradient
        color: '#f5f5f5',
        padding: '2rem'
      }}
    >
      <h2>Welcome, {user?.name || 'Admin'}!</h2>
      <p>
        You are logged in as <strong>Admin / Employer</strong>. Manage your job postings and applications below.
      </p>

      <div className="d-flex flex-column align-items-center mt-4" style={{ width: '300px' }}>
        <Link to="/post-job" className="btn btn-success btn-lg w-100 mb-3 shadow rounded-pill">
          ➕ Post New Job
        </Link>
        <Link to="/my-posted-jobs" className="btn btn-info btn-lg w-100 mb-3 shadow rounded-pill">
          📋 My Posted Jobs
        </Link>
        <Link to="/employer-applications" className="btn btn-secondary btn-lg w-100 shadow rounded-pill">
          📨 View Applications
        </Link>
      </div>
    </div>
  );
}

export default AdminHome;
