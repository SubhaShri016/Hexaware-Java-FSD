import React, { useEffect, useState } from 'react';
import api from '../services/api';

function Applications() {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    api.get(`/jobseekers/applications`, {
      params: { userId: user.id }
    }).then((res) => setApplications(res.data));
  }, []);

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #1f2a48, #f5a25d)',
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <div className="card shadow-lg">
          <div className="card-body">
            <h2 className="card-title text-center mb-4">📑 My Job Applications</h2>
            {applications.length > 0 ? (
              <table className="table table-bordered table-hover table-striped">
                <thead className="table-dark">
                  <tr>
                    <th>Job Title</th>
                    <th>Company</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {applications.map((app) => (
                    <tr key={app.id}>
                      <td>{app.job?.title}</td>
                      <td>{app.job?.employer?.companyName}</td>
                      <td>
                        <span
                          className={`badge ${
                            app.status === 'Pending'
                              ? 'bg-warning text-dark'
                              : app.status === 'Accepted'
                              ? 'bg-success'
                              : app.status === 'Rejected'
                              ? 'bg-danger'
                              : 'bg-secondary'
                          }`}
                        >
                          {app.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="alert alert-info text-center">
                You have not applied to any jobs yet.
              </div>
            )}
            <div className="text-center mt-4">
              <a href="/user-home" className="btn btn-secondary px-4 py-2">
                🔙 Back to Home
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Applications;
