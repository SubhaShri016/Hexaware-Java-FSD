import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';

function EditJob() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: '',
    description: '',
    location: '',
    qualifications: '',
  });

  const [message, setMessage] = useState('');

  // Load job details when component mounts
  useEffect(() => {
    api.get(`/jobs/${id}`)
      .then((res) => {
        const job = res.data;
        setForm({
          title: job.title,
          description: job.description,
          location: job.location,
          qualifications: job.qualifications,
        });
      })
      .catch((err) => {
        console.error(err);
        setMessage('Error loading job details.');
      });
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/jobs/${id}`, form);
      alert('✅ Job updated!');
      navigate('/my-posted-jobs');
    } catch (err) {
      console.error(err);
      alert('❌ Error updating job.');
    }
  };

  return (
    <div className="container mt-5">
      <div className="card shadow-lg">
        <div className="card-body">
          <h2 className="card-title text-center mb-4">✏️ Edit Job</h2>
          {message && (
            <div className="alert alert-danger text-center">{message}</div>
          )}
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Job Title</label>
              <input
                type="text"
                name="title"
                value={form.title}
                onChange={handleChange}
                className="form-control"
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Description</label>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                className="form-control"
                rows="4"
                required
              ></textarea>
            </div>
            <div className="mb-3">
              <label className="form-label">Location</label>
              <input
                type="text"
                name="location"
                value={form.location}
                onChange={handleChange}
                className="form-control"
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Qualifications</label>
              <input
                type="text"
                name="qualifications"
                value={form.qualifications}
                onChange={handleChange}
                className="form-control"
                required
              />
            </div>
            <button type="submit" className="btn btn-primary w-100">
              ✅ Update Job
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default EditJob;
