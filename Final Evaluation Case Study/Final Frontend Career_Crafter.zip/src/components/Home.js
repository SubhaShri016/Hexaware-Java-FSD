import React from 'react';

function Home() {
  return (
    <div
      className="min-vh-100 d-flex flex-column align-items-center text-center"
      style={{
        backgroundImage: `url('/images/cc.jpeg')`,  // ✅ Path from public folder
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }}
    >
      <div className="mt-5 p-4 bg-white bg-opacity-75 rounded shadow">
        <h2 className="fw-bold mb-3">Welcome to CareerCrafter Job Portal!</h2>
        <p className="lead fst-italic">
          Discover opportunities, post jobs, and craft your future with ease.
          Your career journey starts here!
        </p>
      </div>
    </div>
  );
}

export default Home;
