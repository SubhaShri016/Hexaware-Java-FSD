import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useParams, useNavigate } from 'react-router-dom';

export default function JobDetails() {
  const { jobId } = useParams();
  const [job, setJob] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchJobDetails = async () => {
      const user = JSON.parse(localStorage.getItem('user'));
      const token = user?.token;

      try {
        const res = await api.get(`/jobseekers/jobs/${jobId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setJob(res.data);
      } catch (err) {
        console.error(err);
        alert('❌ Error fetching job details.');
      }
    };

    fetchJobDetails();
  }, [jobId]);

  const handleApply = async () => {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user?.token;

    if (!token) {
      alert('❌ Please login to apply.');
      return;
    }

    try {
      await api.post(
        '/jobseekers/apply',
        { jobId, userId: user.id },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      alert('✅ Application submitted!');
      navigate('/applications');
    } catch (err) {
      console.error(err);
      alert('❌ Failed to apply. Please try again.');
    }
  };

  if (!job) return <div className="text-center mt-5">Loading...</div>;

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #1f2a48, #f5a25d)',
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <div className="card shadow-lg">
          <div className="card-header bg-primary text-white">
            <h4>Job Details</h4>
          </div>
          <div className="card-body">
            <p><strong>Title:</strong> {job.title}</p>
            <p><strong>Description:</strong> {job.description}</p>
            <p><strong>Location:</strong> {job.location}</p>
            <p><strong>Qualifications:</strong> {job.qualifications}</p>
            <p><strong>Posted By:</strong> {job.employer?.companyName}</p>
            <button onClick={handleApply} className="btn btn-success me-2">Apply Now</button>
            <button onClick={() => navigate('/jobs')} className="btn btn-secondary">Back to Jobs</button>
          </div>
        </div>
      </div>
    </div>
  );
}
