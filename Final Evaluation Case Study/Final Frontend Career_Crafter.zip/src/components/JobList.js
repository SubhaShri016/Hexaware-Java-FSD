import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

function JobList() {
  const [jobs, setJobs] = useState([]);
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [companyName, setCompanyName] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    const params = {
      title: title.trim(),
      location: location.trim(),
      companyName: companyName.trim(),
    };

    try {
      const res = await api.get('/jobs/search', { params });
      setJobs(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #1f2a48, #f5a25d)',
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <div className="job-table-card bg-white p-4 rounded shadow">
          <h2 className="text-center mb-4">Browse Available Jobs</h2>

          {/* ✅ Search Inputs */}
          <div className="row mb-4">
            <div className="col-md-3 mb-2">
              <input
                type="text"
                className="form-control"
                placeholder="Job Title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
            <div className="col-md-3 mb-2">
              <input
                type="text"
                className="form-control"
                placeholder="Location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
            <div className="col-md-3 mb-2">
              <input
                type="text"
                className="form-control"
                placeholder="Company Name"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
              />
            </div>
            <div className="col-md-3 mb-2">
              <button
                className="btn btn-primary w-100"
                onClick={fetchJobs}
              >
                Search
              </button>
            </div>
          </div>

          {/* ✅ Jobs Table */}
          <table className="table table-bordered table-hover align-middle">
            <thead className="table-dark">
              <tr>
                <th>Title</th>
                <th>Company</th>
                <th>Description</th>
                <th>Location</th>
                <th>Qualifications</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((job) => (
                <tr key={job.id}>
                  <td>{job.title}</td>
                  <td>{job.employer?.companyName}</td>
                  <td>{job.description}</td>
                  <td>{job.location}</td>
                  <td>{job.qualifications}</td>
                  <td>
                    <button
                      onClick={() => navigate(`/job-details/${job.id}`)}
                      className="btn btn-outline-primary btn-sm"
                    >
                      View & Apply
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="text-center mt-4">
            <a href="/user-home" className="btn btn-secondary px-4 py-2">
              🔙 Back to Home
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default JobList;
