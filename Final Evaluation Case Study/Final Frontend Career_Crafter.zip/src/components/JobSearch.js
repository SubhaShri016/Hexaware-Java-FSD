import React, { useState } from 'react';
import api from '../services/api';

export default function JobSearch() {
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [results, setResults] = useState([]);

  const handleSearch = async () => {
    try {
      const res = await api.get('/jobs/search', {
        params: {
          title,
          location,
          companyName,
        },
      });
      setResults(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="container mt-4">
      <h2>🔍 Job Search</h2>

      <div className="mb-3">
        <label>Job Title</label>
        <input
          type="text"
          className="form-control"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g., Developer"
        />
      </div>

      <div className="mb-3">
        <label>Location</label>
        <input
          type="text"
          className="form-control"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          placeholder="e.g., Bangalore"
        />
      </div>

      <div className="mb-3">
        <label>Company Name</label>
        <input
          type="text"
          className="form-control"
          value={companyName}
          onChange={(e) => setCompanyName(e.target.value)}
          placeholder="e.g., Infosys"
        />
      </div>

      <button className="btn btn-primary" onClick={handleSearch}>
        Search Jobs
      </button>

      <hr />

      <h4>Results:</h4>
      {results.length > 0 ? (
        <ul className="list-group">
          {results.map((job) => (
            <li key={job.id} className="list-group-item">
              <h5>{job.title}</h5>
              <p><strong>Location:</strong> {job.location}</p>
              <p><strong>Company:</strong> {job.companyName}</p>
              <p>{job.description}</p>
            </li>
          ))}
        </ul>
      ) : (
        <p>No jobs found. Try different search terms.</p>
      )}
    </div>
  );
}
