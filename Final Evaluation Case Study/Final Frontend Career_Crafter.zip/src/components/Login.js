/*import React, { useState } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post('/users/login', {
        email,
        password,
      });
      const user = response.data;
      console.log(user);

      alert('Login successful!');

      localStorage.setItem('user', JSON.stringify(user));
      localStorage.setItem('userId', user.id);

      if (user.role === 'ADMIN' || user.role === 'EMPLOYER') {
        navigate('/admin-home');
      } else {
        navigate('/user-home');
      }
    } catch (error) {
      if (error.response && error.response.status === 401) {
        setMessage('Invalid credentials');
      } else {
        setMessage('Login failed');
      }
    }
  };

  return (
    <div
      style={{
        background:
          'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url("/images/cc.jpeg")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        minHeight: '100vh',
      }}
      className="d-flex justify-content-center align-items-center"
    >
      <div
        className="col-md-5 p-4 rounded shadow-lg"
        style={{
          backdropFilter: 'blur(8px)',
          backgroundColor: 'rgba(255, 255, 255, 0.75)',
        }}
      >
        <h2 className="text-center mb-4">Login to Your Account</h2>

        {message && (
          <div className="alert alert-danger text-center">{message}</div>
        )}

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input
              type="email"
              className="form-control rounded"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Password:</label>
            <input
              type="password"
              className="form-control rounded"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn btn-success w-100 rounded">
            Login
          </button>
        </form>

        <div className="text-center mt-3">
          <a href="/register" className="text-success text-decoration-underline">
            Don't have an account? Register here
          </a>
        </div>

        <div className="text-center mt-3">
          <a href="/" className="text-success text-decoration-underline">
            ← Back to Home
          </a>
        </div>
      </div>
    </div>
  );
}

export default Login;*/


import React, { useState } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post('/auth/login', {
        email,
        password,
      });

      const { token, role, user } = response.data;
      console.log("Login response:", response.data);

      // ✅ Store everything inside 'user'
      localStorage.setItem('user', JSON.stringify({
        id: user.id,
        name: user.name,
        email: user.email,
        role: role,
        token: token
      }));

      alert('Login successful!');

      if (role === 'ADMIN' || role === 'EMPLOYER') {
        navigate('/admin-home');
      } else {
        navigate('/user-home');
      }

    } catch (error) {
      if (error.response && error.response.status === 401) {
        setMessage('Invalid credentials');
      } else {
        setMessage('Login failed');
      }
    }
  };

  return (
    <div
      style={{
        background:
          'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url("/images/cc.jpeg")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        minHeight: '100vh',
      }}
      className="d-flex justify-content-center align-items-center"
    >
      <div
        className="col-md-5 p-4 rounded shadow-lg"
        style={{
          backdropFilter: 'blur(8px)',
          backgroundColor: 'rgba(255, 255, 255, 0.75)',
        }}
      >
        <h2 className="text-center mb-4">Login to Your Account</h2>

        {message && (
          <div className="alert alert-danger text-center">{message}</div>
        )}

        <form onSubmit={handleLogin}>
          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input
              type="email"
              className="form-control rounded"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Password:</label>
            <input
              type="password"
              className="form-control rounded"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn btn-success w-100 rounded">
            Login
          </button>
        </form>

        <div className="text-center mt-3">
          <a href="/register" className="text-success text-decoration-underline">
            Don't have an account? Register here
          </a>
        </div>

        <div className="text-center mt-3">
          <a href="/" className="text-success text-decoration-underline">
            ← Back to Home
          </a>
        </div>
      </div>
    </div>
  );
}

export default Login;
