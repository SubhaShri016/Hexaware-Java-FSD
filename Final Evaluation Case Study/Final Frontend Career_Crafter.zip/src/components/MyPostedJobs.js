import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';

function MyPostedJobs() {
  const [jobs, setJobs] = useState([]);

  const loadJobs = () => {
    const userId = JSON.parse(localStorage.getItem('user'))?.id;
    if (!userId) {
      console.error('No user ID found. Please login.');
      return;
    }

    api.get(`/jobs/employer/myjobs?userId=${userId}`)
      .then((res) => {
        setJobs(res.data || []);
      })
      .catch((err) => {
        console.error('Error fetching jobs:', err);
      });
  };

  useEffect(() => {
    loadJobs();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this job?')) return;
    try {
      await api.delete(`/jobs/${id}`);
      alert('Job deleted!');
      loadJobs();
    } catch (err) {
      console.error(err);
      alert('Error deleting job.');
    }
  };

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #f5a25d, #1f2a48)',
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <div className="card shadow-lg">
          <div className="card-body">
            <h2 className="card-title text-center mb-4">📋 My Posted Jobs</h2>

            {jobs.length === 0 ? (
              <div className="alert alert-warning text-center">
                You haven't posted any jobs yet.
              </div>
            ) : (
              <table className="table table-bordered table-striped">
                <thead className="table-secondary">
                  <tr>
                    <th>Title</th>
                    <th>Company</th>
                    <th>Location</th>
                    <th>Qualifications</th>
                    <th>Description</th>
                    <th>Posted On</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {jobs.map((job) => (
                    <tr key={job.id}>
                      <td>{job.title}</td>
                      <td>{job.employer?.companyName}</td>
                      <td>{job.location}</td>
                      <td>{job.qualifications}</td>
                      <td>{job.description}</td>
                      <td>{job.createdAt}</td>
                      <td>
                        <Link
                          to={`/edit-job/${job.id}`}
                          className="btn btn-primary btn-sm me-2"
                        >
                          ✏️ Edit
                        </Link>
                        <button
                          onClick={() => handleDelete(job.id)}
                          className="btn btn-danger btn-sm"
                        >
                          🗑️ Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            <div className="text-center mt-4">
              <a href="/admin-home" className="btn btn-secondary px-4 py-2">
                🔙 Back to Home
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MyPostedJobs;
