/*import React, { useState } from 'react';
import api from '../services/api';

function PostJob() {
  const [form, setForm] = useState({
    title: '',
    description: '',
    location: '',
    qualifications: '',
  });

  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const userId = JSON.parse(localStorage.getItem('user'))?.id;
      if (!userId) {
        setMessage('❌ You must be logged in as an Employer.');
        return;
      }

      await api.post(`/jobs/employer?userId=${userId}`, form);

      setMessage('✅ Job posted successfully!');
      setForm({
        title: '',
        description: '',
        location: '',
        qualifications: '',
      });
    } catch (err) {
      console.error(err);
      setMessage('❌ Error posting job.');
    }
  };

  return (
    <div className="container mt-5">
      <div className="card shadow-lg">
        <div className="card-body">
          <h2 className="card-title text-center mb-4">📢 Post New Job</h2>
          {message && <div className="alert alert-info text-center">{message}</div>}
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Job Title</label>
              <input
                type="text"
                name="title"
                value={form.title}
                onChange={handleChange}
                className="form-control"
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Description</label>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                className="form-control"
                rows="4"
                required
              ></textarea>
            </div>
            <div className="mb-3">
              <label className="form-label">Location</label>
              <input
                type="text"
                name="location"
                value={form.location}
                onChange={handleChange}
                className="form-control"
                required
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Qualifications</label>
              <input
                type="text"
                name="qualifications"
                value={form.qualifications}
                onChange={handleChange}
                className="form-control"
                required
              />
            </div>
            <button type="submit" className="btn btn-success w-100">➕ Post Job</button>
          </form>
          <div className="text-center mt-4">
              <a href="/admin-home" className="btn btn-secondary px-4 py-2">
              🔙 Back to Home
               </a>
           </div>
        </div>
      </div>
    </div>
  );
}

export default PostJob;
*/

import React, { useState } from 'react';
import api from '../services/api';

function PostJob() {
  const [form, setForm] = useState({
    title: '',
    description: '',
    location: '',
    qualifications: '',
  });

  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const user = JSON.parse(localStorage.getItem('user'));
    const userId = user?.id;

    if (!userId || !user.token) {
      setMessage('❌ You must be logged in as an Employer.');
      return;
    }

    try {
      const response = await api.post(
        `/jobs/employer`,
        form,
        {
          params: { userId: userId }
        }
      );

      console.log(response.data);
      setMessage('✅ Job posted successfully!');
      setForm({
        title: '',
        description: '',
        location: '',
        qualifications: '',
      });
    } catch (err) {
      console.error(err);
      setMessage('❌ Error posting job.');
    }
  };

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #f5a25d, #1f2a48)',
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <div className="card shadow-lg">
          <div className="card-body">
            <h2 className="card-title text-center mb-4">📢 Post New Job</h2>
            {message && <div className="alert alert-info text-center">{message}</div>}
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label">Job Title</label>
                <input
                  type="text"
                  name="title"
                  value={form.title}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Description</label>
                <textarea
                  name="description"
                  value={form.description}
                  onChange={handleChange}
                  className="form-control"
                  rows="4"
                  required
                ></textarea>
              </div>
              <div className="mb-3">
                <label className="form-label">Location</label>
                <input
                  type="text"
                  name="location"
                  value={form.location}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Qualifications</label>
                <input
                  type="text"
                  name="qualifications"
                  value={form.qualifications}
                  onChange={handleChange}
                  className="form-control"
                  required
                />
              </div>
              <button type="submit" className="btn btn-success w-100">➕ Post Job</button>
            </form>
            <div className="text-center mt-4">
              <a href="/admin-home" className="btn btn-secondary px-4 py-2">
                🔙 Back to Home
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PostJob;
