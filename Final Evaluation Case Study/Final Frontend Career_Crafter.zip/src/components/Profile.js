/*import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

function Profile() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: '',
    phone: '',
    education: '',
    experience: '',
    skills: '',
    linkedin: '',
    github: '',
    user: { id: null }  // ✅ include nested user for userId
  });

  const [message, setMessage] = useState('');

  useEffect(() => {
  const user = JSON.parse(localStorage.getItem('user'));
  if (user && user.id) {
    setForm(prev => ({ ...prev, user: { id: user.id } }));
    api.get('/jobseekers/profile', {
      params: { userId: user.id }
    }).then((res) => {
      if (res.data) {
        setForm({
          ...res.data,
          user: { id: user.id }
        });
      }
    }).catch(console.error);
  }
}, []);


  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      console.log('Sending:', form);
      await api.post('/jobseekers/profile', form);
      setMessage('Profile saved successfully!');
      navigate('/profile/view');
    } catch (err) {
      console.error(err);
      setMessage('Something went wrong.');
    }
  };

  return (
    <div className="container mt-5">
      <div className="card shadow-lg">
        <div className="card-header bg-primary text-white">
          <h4>Manage Your Profile</h4>
        </div>
        <div className="card-body">
          {message && <div className="alert alert-info text-center">{message}</div>}
          <form onSubmit={handleSave}>
            {['fullName', 'phone', 'education', 'experience', 'skills', 'linkedin', 'github'].map((field) => (
              <div className="form-group mb-3" key={field}>
                <label>{field.charAt(0).toUpperCase() + field.slice(1)}</label>
                <input
                  type={(field === 'linkedin' || field === 'github') ? 'url' : 'text'}
                  name={field}
                  className="form-control"
                  value={form[field] || ''}
                  onChange={handleChange}
                  required={!field.includes('linkedin') && !field.includes('github')}
                />
              </div>
            ))}
            <button type="submit" className="btn btn-success">Save Profile</button>
          </form>
          <div className="text-center mt-4">
          <a href="/user-home" className="btn btn-secondary px-4 py-2">
          🔙 Back to Home
          </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;
*/

import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

function Profile() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: '',
    phone: '',
    education: '',
    experience: '',
    skills: '',
    linkedin: '',
    github: '',
  });

  const [message, setMessage] = useState('');

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user && user.id && user.token) {
      api.get(`/employee/profile/${user.id}`, {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      })
        .then((res) => {
          if (res.data) {
            setForm({
              fullName: res.data.fullName || '',
              phone: res.data.phone || '',
              education: res.data.education || '',
              experience: res.data.experience || '',
              skills: res.data.skills || '',
              linkedin: res.data.linkedin || '',
              github: res.data.github || '',
            });
          }
        })
        .catch((error) => {
          console.error('Fetch profile error:', error);
        });
    } else {
      console.error('No user or token found in localStorage');
    }
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      await api.post(`/employee/profile/${user.id}`, form, {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      });
      setMessage('Profile saved successfully!');
      navigate('/profile/view');
    } catch (err) {
      console.error('Save profile error:', err);
      setMessage('Something went wrong.');
    }
  };

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #1f2a48, #f5a25d)', // same gradient: orange ochre to soft blue
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <div className="card shadow-lg">
          <div className="card-header bg-primary text-white">
            <h4>Manage Your Profile</h4>
          </div>
          <div className="card-body">
            {message && <div className="alert alert-info text-center">{message}</div>}
            <form onSubmit={handleSave}>
              {['fullName', 'phone', 'education', 'experience', 'skills', 'linkedin', 'github'].map((field) => (
                <div className="form-group mb-3" key={field}>
                  <label>{field.charAt(0).toUpperCase() + field.slice(1)}</label>
                  <input
                    type={(field === 'linkedin' || field === 'github') ? 'url' : 'text'}
                    name={field}
                    className="form-control"
                    value={form[field] || ''}
                    onChange={handleChange}
                    required={!field.includes('linkedin') && !field.includes('github')}
                  />
                </div>
              ))}
              <button type="submit" className="btn btn-success">Save Profile</button>
            </form>
            <div className="text-center mt-4">
              <a href="/user-home" className="btn btn-secondary px-4 py-2">
                🔙 Back to Home
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Profile;
