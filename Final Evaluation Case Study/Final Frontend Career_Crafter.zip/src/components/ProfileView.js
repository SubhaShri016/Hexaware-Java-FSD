import React, { useEffect, useState } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';

function ProfileView() {
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
      console.error('No user found in localStorage');
      return;
    }

    api.get('/jobseekers/profile', {
      params: { userId: user.id }
    })
      .then((res) => {
        console.log('Loaded profile:', res.data);
        setProfile(res.data);
      })
      .catch((err) => {
        console.error('Error loading profile:', err);
      });
  }, []);

  if (!profile) {
    return (
      <div
        className="container-fluid d-flex justify-content-center align-items-center"
        style={{
          background: 'linear-gradient(135deg, #1f2a48, #f5a25d)',
          minHeight: '100vh',
          color: '#fff',
        }}
      >
        Loading profile...
      </div>
    );
  }

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #1f2a48, #f5a25d)',
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <div className="card shadow-lg">
          <div className="card-header bg-success text-white">
            <h4>Your Profile</h4>
          </div>
          <div className="card-body">
            <p><strong>Full Name:</strong> {profile.fullName}</p>
            <p><strong>Phone:</strong> {profile.phone}</p>
            <p><strong>Education:</strong> {profile.education}</p>
            <p><strong>Experience:</strong> {profile.experience}</p>
            <p><strong>Skills:</strong> {profile.skills}</p>
            <p><strong>LinkedIn:</strong> <a href={profile.linkedin} target="_blank" rel="noreferrer">{profile.linkedin}</a></p>
            <p><strong>GitHub:</strong> <a href={profile.github} target="_blank" rel="noreferrer">{profile.github}</a></p>

            <Link to="/user-home" className="btn btn-outline-primary mt-3">
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProfileView;
