/*import React, { useState } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    role: 'USER',
    companyName: '',
    location: '',
    website: '',
  });
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post('/users/register', form);
      console.log(response.data);
      alert('Registration successful!');
      navigate('/login');
    } catch (error) {
      if (error.response && error.response.status === 409) {
        setMessage('Email already exists');
      } else {
        setMessage('Registration failed');
      }
    }
  };

  return (
    <div
      style={{
        background:
          'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url("/images/cc.jpeg")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        minHeight: '100vh',
      }}
      className="d-flex justify-content-center align-items-center"
    >
      <div
        className="col-md-6 p-4 rounded shadow-lg"
        style={{
          backdropFilter: 'blur(8px)',
          backgroundColor: 'rgba(255, 255, 255, 0.75)',
        }}
      >
        <h2 className="text-center mb-4">Create an Account</h2>

        {message && (
          <div className="alert alert-info text-center">{message}</div>
        )}

        <form onSubmit={handleRegister}>
          <div className="mb-3">
            <label className="form-label">Name:</label>
            <input
              name="name"
              type="text"
              className="form-control rounded"
              value={form.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input
              name="email"
              type="email"
              className="form-control rounded"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Password:</label>
            <input
              name="password"
              type="password"
              className="form-control rounded"
              value={form.password}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Role:</label>
            <select
              name="role"
              className="form-select rounded"
              value={form.role}
              onChange={handleChange}
              required
            >
              <option value="USER">Job Seeker</option>
              <option value="ADMIN">Admin</option>
            </select>
          </div>

          {form.role === 'ADMIN' && (
            <>
              <div className="mb-3">
                <label className="form-label">Company Name:</label>
                <input
                  name="companyName"
                  type="text"
                  className="form-control rounded"
                  value={form.companyName}
                  onChange={handleChange}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Location:</label>
                <input
                  name="location"
                  type="text"
                  className="form-control rounded"
                  value={form.location}
                  onChange={handleChange}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Website:</label>
                <input
                  name="website"
                  type="url"
                  className="form-control rounded"
                  value={form.website}
                  onChange={handleChange}
                />
              </div>
            </>
          )}

          <button type="submit" className="btn btn-success w-100 rounded">
            Register
          </button>
        </form>

        <div className="text-center mt-3">
          <a href="/" className="text-success text-decoration-underline">
            ← Back to Home
          </a>
        </div>
      </div>
    </div>
  );
}

export default Register;
*/

import React, { useState } from 'react';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';

function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    role: 'USER',
    companyName: '',
    location: '',
    website: '',
  });
  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post('/auth/register', form);
      console.log(response.data);
      alert('Registration successful!');
      navigate('/login');
    } catch (error) {
      if (error.response && error.response.status === 409) {
        setMessage('Email already exists');
      } else {
        setMessage('Registration failed');
      }
    }
  };

  return (
    <div
      style={{
        background:
          'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url("/images/cc.jpeg")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        minHeight: '100vh',
      }}
      className="d-flex justify-content-center align-items-center"
    >
      <div
        className="col-md-6 p-4 rounded shadow-lg"
        style={{
          backdropFilter: 'blur(8px)',
          backgroundColor: 'rgba(255, 255, 255, 0.75)',
        }}
      >
        <h2 className="text-center mb-4">Create an Account</h2>

        {message && (
          <div className="alert alert-info text-center">{message}</div>
        )}

        <form onSubmit={handleRegister}>
          <div className="mb-3">
            <label className="form-label">Name:</label>
            <input
              name="name"
              type="text"
              className="form-control rounded"
              value={form.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Email:</label>
            <input
              name="email"
              type="email"
              className="form-control rounded"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Password:</label>
            <input
              name="password"
              type="password"
              className="form-control rounded"
              value={form.password}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Role:</label>
            <select
              name="role"
              className="form-select rounded"
              value={form.role}
              onChange={handleChange}
              required
            >
              <option value="USER">Job Seeker</option>
              <option value="ADMIN">Admin</option>
            </select>
          </div>

          {form.role === 'ADMIN' && (
            <>
              <div className="mb-3">
                <label className="form-label">Company Name:</label>
                <input
                  name="companyName"
                  type="text"
                  className="form-control rounded"
                  value={form.companyName}
                  onChange={handleChange}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Location:</label>
                <input
                  name="location"
                  type="text"
                  className="form-control rounded"
                  value={form.location}
                  onChange={handleChange}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Website:</label>
                <input
                  name="website"
                  type="url"
                  className="form-control rounded"
                  value={form.website}
                  onChange={handleChange}
                />
              </div>
            </>
          )}

          <button type="submit" className="btn btn-success w-100 rounded">
            Register
          </button>
        </form>

        <div className="text-center mt-3">
          <a href="/" className="text-success text-decoration-underline">
            ← Back to Home
          </a>
        </div>
      </div>
    </div>
  );
}

export default Register;

