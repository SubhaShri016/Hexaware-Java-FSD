/*import React, { useState, useEffect } from 'react';
import api from '../services/api';

export default function ResumeUpload() {
  const [file, setFile] = useState(null);
  const [resumePath, setResumePath] = useState('');
  const [message, setMessage] = useState('');
  const [jobSeekerId, setJobSeekerId] = useState(null);

  // ✅ Fetch JobSeeker ID & resume path
  useEffect(() => {
    const fetchJobSeekerProfile = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('user'));
        const userId = user?.id;

        if (!userId) {
          setMessage('❌ User not logged in.');
          return;
        }

        const res = await api.get(`/jobseekers/byUserId?userId=${userId}`);
        setJobSeekerId(res.data.id);

        try {
          const resumeRes = await api.get(`/resumes/get?jobSeekerId=${res.data.id}`);
          setResumePath(resumeRes.data.filePath || '');
        } catch {
          setResumePath('');
        }

      } catch (err) {
        console.error(err);
        setMessage('❌ Error fetching JobSeeker profile.');
      }
    };

    fetchJobSeekerProfile();
  }, []);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) {
      setMessage('❌ Please select a file.');
      return;
    }

    try {
      const formData = new FormData();
      formData.append('file', file);

      await api.post(`/resumes/upload?jobSeekerId=${jobSeekerId}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setMessage('✅ Resume uploaded successfully!');
      setFile(null);

      const resumeRes = await api.get(`/resumes/get?jobSeekerId=${jobSeekerId}`);
      setResumePath(resumeRes.data.filePath || '');

    } catch (err) {
      console.error(err);
      setMessage('❌ Error uploading resume.');
    }
  };

  const handleDelete = async () => {
    try {
      await api.delete(`/resumes/delete?jobSeekerId=${jobSeekerId}`);
      setMessage('✅ Resume deleted successfully!');
      setResumePath('');
    } catch (err) {
      console.error(err);
      setMessage('❌ Error deleting resume.');
    }
  };

  return (
    <div className="container mt-5">
      <h2>📄 Manage Resume</h2>
      {message && <div className="alert alert-info">{message}</div>}

      <div className="mb-3">
        <label className="form-label">Select Resume (PDF)</label>
        <input
          type="file"
          className="form-control"
          accept="application/pdf"
          onChange={handleFileChange}
        />
      </div>

      <button className="btn btn-primary me-2" onClick={handleUpload}>
        Upload Resume
      </button>

      {resumePath && (
        <>
          <a
            href={`http://localhost:8080${resumePath}`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-success me-2"
          >
            View Resume
          </a>
          <button className="btn btn-danger" onClick={handleDelete}>
            Delete Resume
          </button>
        </>
      )}
      <div className="text-center mt-4">
          <a href="/user-home" className="btn btn-secondary px-4 py-2">
          🔙 Back to Home
          </a>
          </div>
    </div>
  );
}
*/

import React, { useState, useEffect } from 'react';
import api from '../services/api';

export default function ResumeUpload() {
  const [file, setFile] = useState(null);
  const [resumePath, setResumePath] = useState('');
  const [message, setMessage] = useState('');
  const [jobSeekerId, setJobSeekerId] = useState(null);

  // ✅ Fetch JobSeeker ID & resume path
  useEffect(() => {
    const fetchJobSeekerProfile = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('user'));
        const userId = user?.id;
        const token = user?.token;

        if (!userId || !token) {
          setMessage('❌ User not logged in.');
          return;
        }

        const res = await api.get(`/jobseekers/byUserId?userId=${userId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        setJobSeekerId(res.data.id);

        try {
          const resumeRes = await api.get(`/resumes/get?jobSeekerId=${res.data.id}`, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          setResumePath(resumeRes.data.filePath || '');
        } catch {
          setResumePath('');
        }

      } catch (err) {
        console.error(err);
        setMessage('❌ Error fetching JobSeeker profile.');
      }
    };

    fetchJobSeekerProfile();
  }, []);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!file) {
      setMessage('❌ Please select a file.');
      return;
    }

    try {
      const user = JSON.parse(localStorage.getItem('user'));
      const token = user?.token;

      const formData = new FormData();
      formData.append('file', file);

      await api.post(`/resumes/upload?jobSeekerId=${jobSeekerId}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${token}`,
        },
      });

      setMessage('✅ Resume uploaded successfully!');
      setFile(null);

      const resumeRes = await api.get(`/resumes/get?jobSeekerId=${jobSeekerId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setResumePath(resumeRes.data.filePath || '');

    } catch (err) {
      console.error(err);
      setMessage('❌ Error uploading resume.');
    }
  };

  const handleDelete = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      const token = user?.token;

      await api.delete(`/resumes/delete?jobSeekerId=${jobSeekerId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setMessage('✅ Resume deleted successfully!');
      setResumePath('');
    } catch (err) {
      console.error(err);
      setMessage('❌ Error deleting resume.');
    }
  };

  const handleView = async () => {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user?.token;

    const filename = resumePath.split('/').pop();
    const fileUrl = `http://localhost:8080/api/resumes/view/${filename}`;

    try {
      const res = await fetch(fileUrl, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        throw new Error('❌ Access denied or file not found');
      }

      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      window.open(blobUrl, '_blank');

    } catch (err) {
      console.error(err);
      alert('❌ Cannot view resume: ' + err.message);
    }
  };

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #1f2a48, #f5a25d)',
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <h2 className="text-white">📄 Manage Resume</h2>
        {message && <div className="alert alert-info">{message}</div>}

        <div className="mb-3">
          <label className="form-label text-white">Select Resume (PDF)</label>
          <input
            type="file"
            className="form-control"
            accept="application/pdf"
            onChange={handleFileChange}
          />
        </div>

        <button className="btn btn-primary me-2" onClick={handleUpload}>
          Upload Resume
        </button>

        {resumePath && (
          <>
            <button
              className="btn btn-success me-2"
              onClick={handleView}
            >
              View Resume
            </button>
            <button className="btn btn-danger" onClick={handleDelete}>
              Delete Resume
            </button>
          </>
        )}

        <div className="text-center mt-4">
          <a href="/user-home" className="btn btn-secondary px-4 py-2">
            🔙 Back to Home
          </a>
        </div>
      </div>
    </div>
  );
}
