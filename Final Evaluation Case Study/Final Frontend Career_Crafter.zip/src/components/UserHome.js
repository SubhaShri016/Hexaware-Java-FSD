import React from 'react';
import { Link } from 'react-router-dom';

function UserHome() {
  const user = JSON.parse(localStorage.getItem('user'));

  return (
    <div
      className="d-flex flex-column justify-content-center align-items-center text-center"
      style={{
        minHeight: '100vh',
        margin: 0,
        background: 'linear-gradient(135deg, #1f2a48, #f5a25d)', // 💙🧡 Blue to ochre
        color: '#f5f5f5'
      }}
    >
      <h2>Welcome, {user?.name}!</h2>
      <p>
        You are logged in as <strong>Job Seeker</strong>. Search and apply for your dream job.
      </p>

      <div
        className="d-flex flex-column align-items-center mt-4"
        style={{ width: '300px', margin: '0 auto' }}
      >
        <Link to="/profile" className="btn btn-primary btn-lg w-100 mb-3 shadow rounded-pill">
          <i className="bi bi-person-circle"></i> Manage Profile
        </Link>

        <Link to="/jobs" className="btn btn-success btn-lg w-100 mb-3 shadow rounded-pill">
          <i className="bi bi-briefcase"></i> Browse & Apply Jobs
        </Link>

        <Link to="/resume" className="btn btn-warning btn-lg w-100 mb-3 shadow rounded-pill">
          <i className="bi bi-upload"></i> Upload Resume
        </Link>

        <Link to="/applications" className="btn btn-info btn-lg w-100 mb-3 shadow rounded-pill">
          <i className="bi bi-journal-text"></i> My Applications
        </Link>
      </div>
    </div>
  );
}

export default UserHome;
