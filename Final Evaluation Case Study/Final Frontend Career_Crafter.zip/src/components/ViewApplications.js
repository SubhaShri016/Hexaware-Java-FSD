/*import React, { useEffect, useState } from 'react';
import api from '../services/api';

function EmployerApplications() {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    const userId = JSON.parse(localStorage.getItem('user'))?.id;
    api.get(`/jobs/employer/applications?userId=${userId}`)
      .then(res => setApplications(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="container mt-5">
      <div className="card shadow-lg">
        <div className="card-body">
          <h2 className="card-title text-center mb-4">📨 Job Applications</h2>

          {applications.length === 0 && (
            <p className="text-center text-muted">No applications yet.</p>
          )}

          {applications.map(app => (
            <div key={app.id} className="mb-4 p-3 border rounded bg-light">
              <h5>Job: <span className="text-primary">{app.job?.title}</span></h5>
              <p><strong>Applicant:</strong> {app.jobSeeker?.user?.name} ({app.jobSeeker?.user?.email})</p>

              {app.resumePath && (
                <a
                  href={`http://localhost:8080${app.resumePath}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-sm btn-outline-primary"
                >
                  📄 View Resume
                </a>
              )}
            </div>
          ))}
        </div>

        <div className="text-center mt-4 mb-4">
              <a href="/admin-home" className="btn btn-secondary px-4 py-2">
              🔙 Back to Home
               </a>
           </div>
      </div>
    </div>
  );
}

export default EmployerApplications;
*/

import React, { useEffect, useState } from 'react';
import api from '../services/api';

function EmployerApplications() {
  const [applications, setApplications] = useState([]);

  useEffect(() => {
    const userId = JSON.parse(localStorage.getItem('user'))?.id;
    api.get(`/jobs/employer/applications?userId=${userId}`)
      .then(res => setApplications(res.data))
      .catch(err => console.error(err));
  }, []);

  const handleViewResume = async (resumePath) => {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user?.token;

    if (!resumePath || !token) {
      alert('Missing resume or token!');
      return;
    }

    const filename = resumePath.split('/').pop();
    const fileUrl = `http://localhost:8080/api/resumes/view/${filename}`;

    try {
      const response = await fetch(fileUrl, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      const blob = await response.blob();
      const file = window.URL.createObjectURL(blob);
      window.open(file, '_blank');
    } catch (err) {
      console.error('Error viewing resume:', err);
      alert('Failed to view resume.');
    }
  };

  return (
    <div
      className="container-fluid py-5"
      style={{
        background: 'linear-gradient(135deg, #f5a25d, #1f2a48)',
        minHeight: '100vh',
      }}
    >
      <div className="container">
        <div className="card shadow-lg">
          <div className="card-body">
            <h2 className="card-title text-center mb-4">📨 Job Applications</h2>

            {applications.length === 0 && (
              <p className="text-center text-muted">No applications yet.</p>
            )}

            {applications.map(app => (
              <div key={app.id} className="mb-4 p-3 border rounded bg-light">
                <h5>Job: <span className="text-primary">{app.job?.title}</span></h5>
                <p><strong>Applicant:</strong> {app.jobSeeker?.user?.name} ({app.jobSeeker?.user?.email})</p>

                {app.resumePath && (
                  <button
                    onClick={() => handleViewResume(app.resumePath)}
                    className="btn btn-sm btn-outline-primary"
                  >
                    📄 View Resume
                  </button>
                )}
              </div>
            ))}
          </div>

          <div className="text-center mt-4 mb-4">
            <a href="/admin-home" className="btn btn-secondary px-4 py-2">
              🔙 Back to Home
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EmployerApplications;
