package com.career_crafter.job_portal.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class DatabaseFailSafeConfig {

    @Bean
    public CommandLineRunner failSafeCheck(Environment env) {
        return args -> {
            String url = env.getProperty("spring.datasource.url");
            String ddlAuto = env.getProperty("spring.jpa.hibernate.ddl-auto");
            String activeProfiles = String.join(",", env.getActiveProfiles());

            // Example: your real DB URL usually contains 'mysql'
            if (url != null && url.contains("mysql")) {
                if (ddlAuto != null && (ddlAuto.equalsIgnoreCase("create") || ddlAuto.equalsIgnoreCase("create-drop"))) {
                    throw new IllegalStateException(
                        "\n🚨 FAIL-SAFE TRIGGERED 🚨\n" +
                        "You are connected to MySQL with ddl-auto=" + ddlAuto +
                        "\nThis can drop or recreate your REAL tables!\n" +
                        "Active profiles: " + activeProfiles +
                        "\nPlease check your configuration."
                    );
                }
            }
        };
    }
}
