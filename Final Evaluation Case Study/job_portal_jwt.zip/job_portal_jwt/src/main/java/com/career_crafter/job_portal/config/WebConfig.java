package com.career_crafter.job_portal.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

  @Override
  public void addResourceHandlers(ResourceHandlerRegistry registry) {
    // ✅ Serve files in YOUR_PROJECT/uploads/ at http://localhost:8080/uploads/...
    registry.addResourceHandler("/uploads/**")
            .addResourceLocations("file:uploads/");
  }
}
