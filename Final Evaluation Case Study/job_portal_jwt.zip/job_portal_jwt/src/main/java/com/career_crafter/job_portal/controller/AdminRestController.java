package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.Job;
import com.career_crafter.job_portal.repository.JobRepository;
import com.career_crafter.job_portal.entity.Application;
import com.career_crafter.job_portal.repository.ApplicationRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000") 
public class AdminRestController {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    // ✅ Get all posted jobs
    @GetMapping("/jobs")
    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    // ✅ Post a new job
    @PostMapping("/jobs")
    public Job createJob(@RequestBody Job job) {
        return jobRepository.save(job);
    }

    // ✅ Delete a job by ID
    @DeleteMapping("/jobs/{id}")
    public void deleteJob(@PathVariable Long id) {
        jobRepository.deleteById(id);
    }

    // ✅ Get all job applications
    @GetMapping("/applications")
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    // ✅ Approve or reject an application (optional)
    @PutMapping("/applications/{id}")
    public Application updateApplicationStatus(
            @PathVariable Long id,
            @RequestParam String status) {

        Application application = applicationRepository.findById(id).orElseThrow();
        application.setStatus(status);
        return applicationRepository.save(application);
    }
}
