package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.Application;
import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.Resume;
import com.career_crafter.job_portal.repository.ApplicationRepository;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.ResumeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/applications")
public class ApplicationRestController {
	@Autowired
	private ResumeRepository resumeRepository;

	@Autowired
	private JobSeekerRepository jobSeekerRepository;


    @Autowired
    private ApplicationRepository applicationRepository;

    @GetMapping
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Application> getApplicationById(@PathVariable Long id) {
        return applicationRepository.findById(id);
    }

    @PostMapping
    public Application createApplication(@RequestBody Application application) {

       
        Long jobSeekerId = application.getJobSeeker().getId();
        JobSeeker jobSeeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new RuntimeException("JobSeeker not found with ID: " + jobSeekerId));

        System.out.println("✅ JobSeeker ID: " + jobSeekerId);

       
        Resume resume = resumeRepository.findTopByJobSeekerOrderByUploadedAtDesc(jobSeeker);
        if (resume == null) {
            throw new RuntimeException("No resume found for JobSeeker ID: " + jobSeekerId);
        }

        System.out.println("✅ Latest Resume Path: " + resume.getFilePath());

       
        application.setResumePath(resume.getFilePath());

        System.out.println("✅ Application resume_path to be saved: " + application.getResumePath());

       
        return applicationRepository.save(application);
    }



    @PutMapping("/{id}")
    public Application updateApplication(@PathVariable Long id, @RequestBody Application updatedApplication) {
        updatedApplication.setId(id);
        return applicationRepository.save(updatedApplication);
    }

    @DeleteMapping("/{id}")
    public void deleteApplication(@PathVariable Long id) {
        applicationRepository.deleteById(id);
    }
}
