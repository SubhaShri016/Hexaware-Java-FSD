package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.dto.RegisterRequestDto;
import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.EmployerRepository;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.UserRepository;
import com.career_crafter.job_portal.security.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmployerRepository employerRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

  
    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    // ✅ Login
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        Authentication authentication = authManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        String token = jwtUtil.generateToken(user);

        Map<String, Object> response = new HashMap<>();
        response.put("token", token);
        response.put("role", user.getRole());
        response.put("user", user);

        return ResponseEntity.ok(response);
    }

    
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequestDto request) {
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body("Email already exists");
        }

       
        User newUser = new User();
        newUser.setName(request.getName());
        newUser.setEmail(request.getEmail());
        newUser.setPassword(passwordEncoder.encode(request.getPassword()));
        newUser.setRole(request.getRole());

        User savedUser = userRepository.save(newUser);

       
        if ("EMPLOYER".equalsIgnoreCase(savedUser.getRole()) ||
            "ADMIN".equalsIgnoreCase(savedUser.getRole())) {

            Employer employer = new Employer();
            employer.setCompanyName(request.getCompanyName());
            employer.setLocation(request.getLocation());
            employer.setWebsite(request.getWebsite());
            employer.setUser(savedUser);

            employerRepository.save(employer);
        }
        if ("USER".equalsIgnoreCase(savedUser.getRole())) {
            JobSeeker jobSeeker = new JobSeeker();
            jobSeeker.setUser(savedUser);
            jobSeekerRepository.save(jobSeeker);
        }

        return ResponseEntity.ok("User registered successfully");
    }

   
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(@RequestHeader("Authorization") String authHeader) {
        String token = authHeader.substring(7);
        String email = jwtUtil.extractUsername(token);

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return ResponseEntity.ok(user);
    }

    // ✅ Stateless logout
    @PostMapping("/logout")
    public ResponseEntity<?> logout() {
        return ResponseEntity.ok("Client should remove JWT token; stateless logout complete.");
    }
}

// ✅ DTO for login
class LoginRequest {
    private String email;
    private String password;

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}
