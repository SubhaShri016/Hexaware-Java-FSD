package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/employee")
@CrossOrigin(origins = "http://localhost:3000") // React
public class EmployeeRestController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private JobSeekerRepository jobSeekerRepository;
    @Autowired
    private JobRepository jobRepository;
    @Autowired
    private ResumeRepository resumeRepository;
    @Autowired
    private ApplicationRepository applicationRepository;

    @GetMapping("/profile/{userId}")
    public JobSeeker getProfile(@PathVariable Long userId) {
        User user = userRepository.findById(userId).orElseThrow();
        return jobSeekerRepository.findByUser(user);
    }

    @PostMapping("/profile/{userId}")
    public JobSeeker saveProfile(@PathVariable Long userId, @RequestBody JobSeeker data) {
        User user = userRepository.findById(userId).orElseThrow();
        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        if (seeker == null) {
            seeker = new JobSeeker();
            seeker.setUser(user);
        }
        seeker.setFullName(data.getFullName());
        seeker.setPhone(data.getPhone());
        seeker.setEducation(data.getEducation());
        seeker.setExperience(data.getExperience());
        seeker.setSkills(data.getSkills());
        seeker.setLinkedin(data.getLinkedin());
        seeker.setGithub(data.getGithub());
        return jobSeekerRepository.save(seeker);
    }

    @GetMapping("/jobs")
    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    @PostMapping("/apply")
    public Application applyForJob(@RequestParam Long userId, @RequestParam Long jobId) {
        User user = userRepository.findById(userId).orElseThrow();
        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        Job job = jobRepository.findById(jobId).orElseThrow();

        boolean exists = applicationRepository.findByJobSeeker(seeker)
                .stream().anyMatch(app -> app.getJob().getId().equals(jobId));
        if (exists) {
            throw new RuntimeException("Already applied for this job");
        }

        Application app = new Application();
        app.setJob(job);
        app.setJobSeeker(seeker);
        app.setStatus("Applied");
        return applicationRepository.save(app);
    }

    @GetMapping("/applications/{userId}")
    public List<Application> viewApplications(@PathVariable Long userId) {
        User user = userRepository.findById(userId).orElseThrow();
        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        return applicationRepository.findByJobSeeker(seeker);
    }
    @PostMapping("/resume/{userId}")
    public Resume uploadResume(@PathVariable Long userId, @RequestParam("file") MultipartFile file) throws IOException {
        User user = userRepository.findById(userId).orElseThrow();
        JobSeeker seeker = jobSeekerRepository.findByUser(user);

        String uploadDir = new File("uploads").getAbsolutePath();
        new File(uploadDir).mkdirs();

        String fileName = userId + "_" + file.getOriginalFilename();
        String filePath = uploadDir + File.separator + fileName;

        file.transferTo(new File(filePath));

        Resume resume = resumeRepository.findByJobSeeker(seeker).orElse(null);
        if (resume == null) {
            resume = new Resume();
            resume.setJobSeeker(seeker);
        }
        resume.setFilePath("/uploads/" + fileName);

        return resumeRepository.save(resume);
    }


    @GetMapping("/resume/{userId}")
    public Resume getResume(@PathVariable Long userId) {
        User user = userRepository.findById(userId).orElseThrow();
        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        return resumeRepository.findByJobSeeker(seeker).orElse(null);
    }


}
