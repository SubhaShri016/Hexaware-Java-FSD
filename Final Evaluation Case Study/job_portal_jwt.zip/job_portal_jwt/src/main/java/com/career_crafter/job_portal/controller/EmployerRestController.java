package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.repository.EmployerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/employers")
public class EmployerRestController {

    @Autowired
    private EmployerRepository employerRepository;

    @GetMapping
    public List<Employer> getAllEmployers() {
        return employerRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Employer> getEmployerById(@PathVariable Long id) {
        return employerRepository.findById(id);
    }

    @PostMapping
    public Employer createEmployer(@RequestBody Employer employer) {
        return employerRepository.save(employer);
    }

    @PutMapping("/{id}")
    public Employer updateEmployer(@PathVariable Long id, @RequestBody Employer updatedEmployer) {
        updatedEmployer.setId(id);
        return employerRepository.save(updatedEmployer);
    }

    @DeleteMapping("/{id}")
    public void deleteEmployer(@PathVariable Long id) {
        employerRepository.deleteById(id);
    }
}
