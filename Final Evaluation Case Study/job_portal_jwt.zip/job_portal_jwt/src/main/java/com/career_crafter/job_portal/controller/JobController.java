package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/jobs")
public class JobController {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private EmployerRepository employerRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private ResumeRepository resumeRepository;

    @PostMapping("/add")
    public String addJob(@RequestParam String title, @RequestParam String description,
                         @RequestParam String location, @RequestParam String qualifications,
                         HttpSession session, RedirectAttributes redirect) {

        User user = (User) session.getAttribute("user");
        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            redirect.addFlashAttribute("message", "Login as Employer");
            return "redirect:/login";
        }

        Employer employer = employerRepository.findByUserId(user.getId());
        if (employer == null) {
            redirect.addFlashAttribute("message", "Employer profile not found");
            return "redirect:/login";
        }

        Job job = new Job();
        job.setEmployer(employer);
        job.setTitle(title);
        job.setDescription(description);
        job.setLocation(location);
        job.setQualifications(qualifications);
        jobRepository.save(job);

        redirect.addFlashAttribute("message", "Job posted!");
        return "redirect:/admin/home";
    }

    @GetMapping("/employer/myjobs")
    public String myJobs(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }
        Employer employer = employerRepository.findByUserId(user.getId());
        model.addAttribute("jobs", jobRepository.findByEmployer(employer));
        return "forward:/my_jobs.jsp";
    }

    @GetMapping("/employer/applications")
    public String viewApplications(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        List<Application> apps = applicationRepository.findByEmployerId(user.getId());
        for (Application app : apps) {
            JobSeeker seeker = app.getJobSeeker();
            Resume resume = resumeRepository.findTopByJobSeekerOrderByUploadedAtDesc(seeker);
            if (resume != null) {
                app.setResumePath(resume.getFilePath());
            }
        }
        model.addAttribute("applications", apps);
        return "forward:/view_applications.jsp";
    }

    
}
