package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;
import com.career_crafter.job_portal.service.MailService; // ✅ make sure this import is correct

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/jobs")
@CrossOrigin(origins = "http://localhost:3000")
public class JobRestController {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private EmployerRepository employerRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MailService mailService; // ✅ use your MailService

    // ✅ GET all jobs
    @GetMapping
    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    // ✅ GET job by ID
    @GetMapping("/{id}")
    public ResponseEntity<Job> getJobById(@PathVariable Long id) {
        return jobRepository.findById(id)
                .map(job -> new ResponseEntity<>(job, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // ✅ POST new job by employer
    @PostMapping("/employer")
    public ResponseEntity<Job> postJobForEmployer(@RequestParam Long userId, @RequestBody Job job) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        Employer employer = employerRepository.findByUserId(user.getId());
        if (employer == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        job.setEmployer(employer);
        Job savedJob = jobRepository.save(job);

        // ✅ Safe: wrap mail send in try-catch so DB save isn't affected
        try {
            mailService.sendMail(
                    user.getEmail(),
                    "New Job Posted",
                    "Hello " + user.getName() + ",\n\nYour job \"" + job.getTitle() + "\" has been posted!\n\nThanks,\nCareerCrafter"
            );
        } catch (Exception e) {
            System.err.println("❌ Failed to send mail: " + e.getMessage());
            e.printStackTrace(); // optional: log it or use a logger
        }

        return new ResponseEntity<>(savedJob, HttpStatus.CREATED);
    }

    // ✅ Employer's own jobs
    @GetMapping("/employer/myjobs")
    public ResponseEntity<List<Job>> getMyJobs(@RequestParam Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        Employer employer = employerRepository.findByUserId(user.getId());
        if (employer == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        List<Job> jobs = jobRepository.findByEmployer(employer);
        return new ResponseEntity<>(jobs, HttpStatus.OK);
    }

    // ✅ Employer applications
    @GetMapping("/employer/applications")
    public ResponseEntity<List<Application>> getApplicationsForEmployer(@RequestParam Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }

        List<Application> applications = applicationRepository.findByEmployerId(user.getId());

        for (Application app : applications) {
            JobSeeker seeker = app.getJobSeeker();
            if (seeker != null) {
                Resume latestResume = resumeRepository.findTopByJobSeekerOrderByUploadedAtDesc(seeker);
                if (latestResume != null) {
                    app.setResumePath(latestResume.getFilePath());
                }
            }
        }

        return new ResponseEntity<>(applications, HttpStatus.OK);
    }

    // ✅ DELETE job
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJob(@PathVariable Long id) {
        if (!jobRepository.existsById(id)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // 1) Delete applications linked to this job
        applicationRepository.deleteByJobId(id);

        // 2) Then delete the job
        jobRepository.deleteById(id);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    // ✅ UPDATE job
    @PutMapping("/{id}")
    public ResponseEntity<Job> updateJob(@PathVariable Long id, @RequestBody Job updatedJob) {
        return jobRepository.findById(id).map(existingJob -> {
            existingJob.setTitle(updatedJob.getTitle());
            existingJob.setDescription(updatedJob.getDescription());
            existingJob.setLocation(updatedJob.getLocation());
            existingJob.setQualifications(updatedJob.getQualifications());
            Job savedJob = jobRepository.save(existingJob);
            return new ResponseEntity<>(savedJob, HttpStatus.OK);
        }).orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // ✅ SEARCH jobs
    @GetMapping("/search")
    public List<Job> searchJobs(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String companyName) {

        return jobRepository.searchJobs(
                title != null ? title : "",
                location != null ? location : "",
                companyName != null ? companyName : ""
        );
    }
}
