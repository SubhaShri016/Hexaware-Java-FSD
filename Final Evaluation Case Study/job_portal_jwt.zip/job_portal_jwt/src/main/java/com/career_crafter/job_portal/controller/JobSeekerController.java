package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.UUID;

@Controller
@RequestMapping("/jobseeker")
public class JobSeekerController {

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @GetMapping("/profile")
    public String profileForm(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }
        model.addAttribute("jobSeeker", jobSeekerRepository.findByUser(user));
        return "forward:/jobseeker_profile.jsp";
    }

    @PostMapping("/profile/save")
    public String saveProfile(@RequestParam String fullName, @RequestParam String phone,
                              @RequestParam String education, @RequestParam String experience,
                              @RequestParam String skills, @RequestParam(required = false) String linkedin,
                              @RequestParam(required = false) String github,
                              HttpSession session) {

        User user = (User) session.getAttribute("user");
        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        if (seeker == null) seeker = new JobSeeker();
        seeker.setUser(user);
        seeker.setFullName(fullName);
        seeker.setPhone(phone);
        seeker.setEducation(education);
        seeker.setExperience(experience);
        seeker.setSkills(skills);
        seeker.setLinkedin(linkedin);
        seeker.setGithub(github);
        jobSeekerRepository.save(seeker);

        return "redirect:/jobseeker/profile/view";
    }

    @GetMapping("/profile/view")
    public String viewProfile(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }
        model.addAttribute("jobSeeker", jobSeekerRepository.findByUser(user));
        return "forward:/jobseeker_view_profile.jsp";
    }

    @GetMapping("/jobs")
    public String viewJobs(Model model) {
        model.addAttribute("jobs", jobRepository.findAll());
        return "forward:/job_list.jsp";
    }

    @GetMapping("/resume")
    public String showResumeForm(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        JobSeeker seeker = jobSeekerRepository.findByUser(user);

        // ✅ FIXED: unwrap Optional safely
        model.addAttribute("resume", resumeRepository.findByJobSeeker(seeker).orElse(null));
        return "forward:/resume_upload.jsp";
    }

    @PostMapping("/resume/uploads")
    public String uploadResume(@RequestParam("file") MultipartFile file, HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        try {
            String uploadDir = new File("uploads").getAbsolutePath();
            new File(uploadDir).mkdirs();
            String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
            file.transferTo(new File(uploadDir + "/" + fileName));

            // ✅ FIXED: unwrap Optional safely
            Resume resume = resumeRepository.findByJobSeeker(seeker).orElse(new Resume());
            resume.setJobSeeker(seeker);
            resume.setFilePath("uploads/" + fileName);
            resumeRepository.save(resume);
            model.addAttribute("message", "Resume uploaded!");
        } catch (IOException e) {
            model.addAttribute("message", "Upload failed.");
        }
        return "forward:/resume_upload.jsp";
    }

    @PostMapping("/apply")
    public String apply(@RequestParam Long jobId, HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        Job job = jobRepository.findById(jobId).orElse(null);

        if (applicationRepository.findByJobSeeker(seeker).stream().anyMatch(app -> app.getJob().getId().equals(jobId))) {
            model.addAttribute("message", "Already applied!");
        } else {
            // ✅ Get latest resume
            Resume resume = resumeRepository.findTopByJobSeekerOrderByUploadedAtDesc(seeker);
            if (resume == null) {
                model.addAttribute("message", "❌ No resume found! Please upload before applying.");
                return "redirect:/jobseeker/jobs";
            }

            Application app = new Application();
            app.setJob(job);
            app.setJobSeeker(seeker);
            app.setStatus("Applied");
            app.setResumePath(resume.getFilePath());  // ✅ Save it!

            applicationRepository.save(app);
            model.addAttribute("message", "Application submitted!");
        }

        return "redirect:/jobseeker/applications";
    }


    @GetMapping("/applications")
    public String myApplications(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        model.addAttribute("applications", applicationRepository.findByJobSeeker(seeker));
        return "forward:/jobseeker_applications.jsp";
    }

    @GetMapping("/resume/view/{filename:.+}")
    public void viewResume(@PathVariable String filename, HttpServletResponse response) throws IOException {
        Path file = Paths.get("src/main/resources/static/uploads/").resolve(filename);
        if (Files.exists(file)) {
            response.setContentType(Files.probeContentType(file));
            Files.copy(file, response.getOutputStream());
            response.getOutputStream().flush();
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }
}
