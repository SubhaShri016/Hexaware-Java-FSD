package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;
import com.career_crafter.job_portal.service.MailService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/jobseekers")
@CrossOrigin(origins = "http://localhost:3000")
public class JobSeekerRestController {

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private MailService mailService; // ✅ correct service

    // ✅ CRUD for JobSeeker
    @GetMapping
    public List<JobSeeker> getAllJobSeekers() {
        return jobSeekerRepository.findAll();
    }

    @GetMapping("/{id}")
    public JobSeeker getJobSeekerById(@PathVariable Long id) {
        return jobSeekerRepository.findById(id).orElseThrow(() -> new RuntimeException("Not found"));
    }

    @PostMapping
    public JobSeeker createJobSeeker(@RequestBody JobSeeker jobSeeker) {
        return jobSeekerRepository.save(jobSeeker);
    }

    @PutMapping("/{id}")
    public JobSeeker updateJobSeeker(@PathVariable Long id, @RequestBody JobSeeker updatedJobSeeker) {
        updatedJobSeeker.setId(id);
        return jobSeekerRepository.save(updatedJobSeeker);
    }

    @DeleteMapping("/{id}")
    public void deleteJobSeeker(@PathVariable Long id) {
        jobSeekerRepository.deleteById(id);
    }

    // ✅ Browse jobs
    @GetMapping("/jobs")
    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    @GetMapping("/jobs/{id}")
    public Job getJobDetails(@PathVariable Long id) {
        return jobRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found"));
    }

    // ✅ Get applications by userId
    @GetMapping("/applications")
    public List<Application> getApplications(@RequestParam Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!"USER".equalsIgnoreCase(user.getRole())) {
            throw new RuntimeException("Not a USER role");
        }

        JobSeeker jobSeeker = jobSeekerRepository.findByUser(user);
        return applicationRepository.findByJobSeeker(jobSeeker);
    }

    // ✅ Get & Save Profile
    @GetMapping("/profile")
    public JobSeeker getProfile(@RequestParam Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!"USER".equalsIgnoreCase(user.getRole())) {
            throw new RuntimeException("Not a USER role");
        }

        JobSeeker jobSeeker = jobSeekerRepository.findByUser(user);
        if (jobSeeker == null) throw new RuntimeException("Profile not found");
        return jobSeeker;
    }

    @PostMapping("/profile")
    public String saveProfile(@RequestBody JobSeeker updatedJobSeeker) {
        if (updatedJobSeeker.getUser() == null || updatedJobSeeker.getUser().getId() == null) {
            throw new RuntimeException("User ID is required");
        }

        Long userId = updatedJobSeeker.getUser().getId();
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!"USER".equalsIgnoreCase(user.getRole())) {
            throw new RuntimeException("Not a USER role");
        }

        JobSeeker jobSeeker = jobSeekerRepository.findByUser(user);
        if (jobSeeker == null) {
            jobSeeker = new JobSeeker();
            jobSeeker.setUser(user);
        }

        jobSeeker.setFullName(updatedJobSeeker.getFullName());
        jobSeeker.setPhone(updatedJobSeeker.getPhone());
        jobSeeker.setEducation(updatedJobSeeker.getEducation());
        jobSeeker.setExperience(updatedJobSeeker.getExperience());
        jobSeeker.setSkills(updatedJobSeeker.getSkills());
        jobSeeker.setLinkedin(updatedJobSeeker.getLinkedin());
        jobSeeker.setGithub(updatedJobSeeker.getGithub());

        jobSeekerRepository.save(jobSeeker);
        return "Profile updated!";
    }

    // ✅ Apply for job & send mail
 // ✅ Apply for job & send mail with safe try-catch
    @PostMapping("/apply")
    public String applyJob(@RequestBody Map<String, Long> payload) {
        Long jobId = payload.get("jobId");
        Long userId = payload.get("userId");

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        JobSeeker jobSeeker = jobSeekerRepository.findByUser(user);
        if (jobSeeker == null) {
            throw new RuntimeException("JobSeeker not found");
        }

        // ✅ Get latest resume
        Resume resume = resumeRepository.findTopByJobSeekerOrderByUploadedAtDesc(jobSeeker);
        if (resume == null) {
            throw new RuntimeException("No resume found!");
        }

        // ✅ Create application with resume path
        Application app = new Application();
        app.setJob(job);
        app.setJobSeeker(jobSeeker);
        app.setStatus("APPLIED");
        app.setResumePath(resume.getFilePath());  // ✅ Set it here!

        applicationRepository.save(app);

        // ✅ Send mail to job seeker
        try {
            mailService.sendMail(
                user.getEmail(),
                "Application Submitted!",
                "Hi " + user.getName() + ",\n\nYou have successfully applied for: " + job.getTitle() + ".\n\nThanks,\nCareerCrafter"
            );
        } catch (Exception e) {
            System.err.println("❌ Failed to send mail to Job Seeker: " + e.getMessage());
        }

        // ✅ Send mail to employer
        try {
            String employerEmail = job.getEmployer().getUser().getEmail();
            mailService.sendMail(
                employerEmail,
                "New Application Received",
                "Hello,\n\nYou have received a new application for: " + job.getTitle() + ".\n\nThanks,\nCareerCrafter"
            );
        } catch (Exception e) {
            System.err.println("❌ Failed to send mail to Employer: " + e.getMessage());
        }

        return "Application submitted!";
    }


    @GetMapping("/byUserId")
    public ResponseEntity<JobSeeker> getByUserId(@RequestParam Long userId) {
        JobSeeker js = jobSeekerRepository.findByUserId(userId);
        return js != null ? ResponseEntity.ok(js) : ResponseEntity.notFound().build();
    }
}
