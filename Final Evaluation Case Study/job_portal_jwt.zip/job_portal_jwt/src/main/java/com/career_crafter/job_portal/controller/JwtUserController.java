package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.Application;
import com.career_crafter.job_portal.entity.Job;
import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.ApplicationRepository;
import com.career_crafter.job_portal.repository.JobRepository;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.UserRepository;
import com.career_crafter.job_portal.security.JwtUtil;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class JwtUserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private JwtUtil jwtUtil;

    // ✅ 1. Test: simple hello
    @GetMapping("/hello")
    public String hello() {
        return "Hello, you are authenticated with JWT!";
    }

    // ✅ 2. Get current user profile
    @GetMapping("/me")
    public ResponseEntity<User> getCurrentUser(Authentication authentication) {
        String email = authentication.getName(); // from JwtFilter
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return ResponseEntity.ok(user);
    }

    // ✅ 3. Get all jobs
    @GetMapping("/jobs")
    public List<Job> getJobs() {
        return jobRepository.findAll();
    }

    // ✅ 4. Apply for a job
    @PostMapping("/apply/{jobId}")
    public ResponseEntity<String> applyJob(@PathVariable Long jobId, Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email) // ✅ FIXED HERE
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!"USER".equalsIgnoreCase(user.getRole())) {
            return ResponseEntity.status(403).body("Only job seekers can apply");
        }

        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        boolean alreadyApplied = applicationRepository.findByJobSeeker(seeker)
                .stream().anyMatch(a -> a.getJob().getId().equals(jobId));
        if (alreadyApplied) {
            return ResponseEntity.badRequest().body("Already applied!");
        }

        Application app = new Application();
        app.setJob(job);
        app.setJobSeeker(seeker);
        app.setStatus("Applied");
        applicationRepository.save(app);

        return ResponseEntity.ok("Applied successfully!");
    }

    // ✅ 5. View my applications
    @GetMapping("/applications")
    public ResponseEntity<List<Application>> myApplications(Authentication authentication) {
        String email = authentication.getName();
        User user = userRepository.findByEmail(email) // ✅ FIXED HERE
                .orElseThrow(() -> new RuntimeException("User not found"));

        JobSeeker seeker = jobSeekerRepository.findByUser(user);
        List<Application> applications = applicationRepository.findByJobSeeker(seeker);
        return ResponseEntity.ok(applications);
    }
}
