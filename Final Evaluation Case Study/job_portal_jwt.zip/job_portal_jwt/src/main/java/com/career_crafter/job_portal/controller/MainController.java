package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.EmployerRepository;
import com.career_crafter.job_portal.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
public class MainController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private EmployerRepository employerRepository;


    // Home page
    @GetMapping("/")
    public String index() {
        return "forward:/index.jsp";
    }

    // Login page
    @GetMapping("/login")
    public String loginPage() {
        return "forward:/loginpage.jsp";
    }

    // Register page
    @GetMapping("/register")
    public String registerPage() {
        return "forward:/registerpage.jsp";
    }

    // Admin home page
    @GetMapping("/admin/home")
    public String adminHome(HttpSession session, Model model) {
        if (!isRole(session, "ADMIN")) return "redirect:/login";
        model.addAttribute("user", session.getAttribute("user"));
        return "forward:/adminhome.jsp";
    }

    // User home page
    @GetMapping("/user/home")
    public String userHome(HttpSession session, Model model) {
        if (!isRole(session, "USER")) return "redirect:/login";
        model.addAttribute("user", session.getAttribute("user"));
        return "forward:/userhome.jsp";
    }

    // Employer home page
    

    // Handle Registration
    @PostMapping("/register")
    public String registerUser(@RequestParam String name,
                               @RequestParam String email,
                               @RequestParam String password,
                               @RequestParam String role,
                               @RequestParam(required = false) String companyName,
                               @RequestParam(required = false) String location,
                               @RequestParam(required = false) String website,
                               Model model) {

        if (userRepository.existsByEmail(email)) {
            model.addAttribute("message", "Email already registered!");
            return "forward:/registerpage.jsp";
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role.toUpperCase());

        userRepository.save(user);

        if (role.equalsIgnoreCase("ADMIN")) {
            Employer employer = new Employer();
            employer.setUser(user);
            employer.setCompanyName(companyName != null ? companyName : "Default Company");
            employer.setLocation(location != null ? location : "Default Location");
            employer.setWebsite(website != null ? website : "https://default.com");

            employerRepository.save(employer);
        }

        model.addAttribute("message", "Registration successful! Please login.");
        return "forward:/loginpage.jsp";
    }


    // Handle Login
    @PostMapping("/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            Model model,
                            HttpSession session) {

        User user = userRepository.findByEmailAndPassword(email, password);
        if (user == null) {
            model.addAttribute("message", "Invalid credentials!");
            return "forward:/loginpage.jsp";
        }

        // Store user in session
        session.setAttribute("user", user);
        String role = user.getRole().toUpperCase();

        switch (role) {
            case "ADMIN":
            case "EMPLOYER":  // just in case old records still use EMPLOYER
                return "redirect:/admin/home";
            case "USER":
                return "redirect:/user/home";
            default:
                model.addAttribute("message", "Unknown role!");
                return "forward:/loginpage.jsp"; 
        }
    }


    // Handle logout
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // Utility method to check role
    private boolean isRole(HttpSession session, String expectedRole) {
        User user = (User) session.getAttribute("user");
        return user != null && user.getRole().equalsIgnoreCase(expectedRole);
    }
}     