/*package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.Resume;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.ResumeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/resumes")
@CrossOrigin(origins = "http://localhost:3000")
public class ResumeRestController {

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    // ✅ Get Resume by JobSeeker ID
    @GetMapping("/get")
    public Resume getResumeByJobSeekerId(@RequestParam Long jobSeekerId) {
        JobSeeker jobSeeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new RuntimeException("JobSeeker not found for ID: " + jobSeekerId));

        return resumeRepository.findByJobSeeker(jobSeeker)
                .orElseThrow(() -> new RuntimeException("Resume not found for JobSeeker ID: " + jobSeekerId));
    }

    // ✅ Upload Resume
    @PostMapping("/upload")
    public Resume uploadResume(@RequestParam("file") MultipartFile file,
                               @RequestParam("jobSeekerId") Long jobSeekerId) {

        if (file.isEmpty()) {
            throw new RuntimeException("File is empty");
        }

        JobSeeker jobSeeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new RuntimeException("JobSeeker not found for ID: " + jobSeekerId));

        String uploadDir = "uploads/";
        String filename = jobSeekerId + "_" + file.getOriginalFilename();
        Path path = Paths.get(uploadDir + filename);

        try {
            Files.createDirectories(path.getParent());
            Files.write(path, file.getBytes());
        } catch (IOException e) {
            throw new RuntimeException("Failed to store file", e);
        }

        Resume resume = resumeRepository.findByJobSeeker(jobSeeker)
                .orElse(new Resume());

        resume.setJobSeeker(jobSeeker);
        resume.setFilePath("/uploads/" + filename);

        return resumeRepository.save(resume);
    }

    // ✅ Delete Resume — CORRECTED
    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteResume(@RequestParam Long jobSeekerId) {
        JobSeeker js = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new RuntimeException("JobSeeker not found!"));

        Resume resume = resumeRepository.findByJobSeeker(js)
                .orElseThrow(() -> new RuntimeException("Resume not found!"));

        // ✅ New: Delete from ROOT uploads directory, NOT src/static
        Path file = Paths.get("uploads/" + new java.io.File(resume.getFilePath()).getName());

        try {
            Files.deleteIfExists(file);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error deleting file: " + e.getMessage());
        }

        resumeRepository.delete(resume);
        return ResponseEntity.ok("Resume deleted successfully");
    }
}
*/
package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.Resume;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.ResumeRepository;
import com.career_crafter.job_portal.repository.UserRepository;
import com.career_crafter.job_portal.security.JwtUtil;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/resumes")
@CrossOrigin(origins = "http://localhost:3000")
public class ResumeRestController {

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;
    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserRepository userRepository;


    // ✅ Get Resume by JobSeeker ID (using existing findByJobSeeker)
    @GetMapping("/get")
    public Resume getResumeByJobSeekerId(@RequestParam Long jobSeekerId) {
        System.out.println("🔍 Incoming jobSeekerId: " + jobSeekerId);

        JobSeeker jobSeeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new RuntimeException("❌ JobSeeker not found for ID: " + jobSeekerId));
        System.out.println("✅ JobSeeker found: " + jobSeeker.getId());

        return resumeRepository.findByJobSeeker(jobSeeker)
                .orElseThrow(() -> new RuntimeException("❌ Resume not found for JobSeeker ID: " + jobSeekerId));
    }

    // ✅ Upload Resume
    @PostMapping("/upload")
    public Resume uploadResume(@RequestParam("file") MultipartFile file,
                               @RequestParam("jobSeekerId") Long jobSeekerId) {

        if (file.isEmpty()) {
            throw new RuntimeException("File is empty");
        }

        JobSeeker jobSeeker = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new RuntimeException("JobSeeker not found for ID: " + jobSeekerId));

        String uploadDir = "uploads/";
        String filename = jobSeekerId + "_" + file.getOriginalFilename();
        Path path = Paths.get(uploadDir + filename);

        try {
            Files.createDirectories(path.getParent());
            Files.write(path, file.getBytes());
        } catch (IOException e) {
            throw new RuntimeException("Failed to store file", e);
        }

        Resume resume = resumeRepository.findByJobSeeker(jobSeeker)
                .orElse(new Resume());

        resume.setJobSeeker(jobSeeker);
        resume.setFilePath("/uploads/" + filename);

        return resumeRepository.save(resume);
    }

    // ✅ Delete Resume
    @DeleteMapping("/delete")
    public ResponseEntity<?> deleteResume(@RequestParam Long jobSeekerId) {
        JobSeeker js = jobSeekerRepository.findById(jobSeekerId)
                .orElseThrow(() -> new RuntimeException("JobSeeker not found!"));

        Resume resume = resumeRepository.findByJobSeeker(js)
                .orElseThrow(() -> new RuntimeException("Resume not found!"));

        Path file = Paths.get("uploads/" + new java.io.File(resume.getFilePath()).getName());

        try {
            Files.deleteIfExists(file);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error deleting file: " + e.getMessage());
        }

        resumeRepository.delete(resume);
        return ResponseEntity.ok("Resume deleted successfully");
    }
    @GetMapping("/view/{filename:.+}")
    public void viewResume(
        @PathVariable String filename,
        HttpServletResponse response,
        @RequestHeader("Authorization") String authHeader
    ) throws IOException {
        // ✅ Extract JWT token
        String token = authHeader.substring(7);

        // ✅ Validate JWT, get user email (or ID)
        String email = jwtUtil.extractUsername(token);
        User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Invalid user"));

        // ✅ Optional: Check if user owns this resume
        // Example: check if filename starts with their JobSeeker ID
        // (or look up by JobSeeker/Resume relationship in DB if needed)

        // ✅ Serve file securely
        Path filePath = Paths.get("uploads").resolve(filename);
        if (!Files.exists(filePath)) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        response.setContentType(Files.probeContentType(filePath));
        Files.copy(filePath, response.getOutputStream());
        response.getOutputStream().flush();
    }

}


