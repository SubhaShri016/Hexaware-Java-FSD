package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.EmployerRepository;
import com.career_crafter.job_portal.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.career_crafter.job_portal.dto.RegisterRequestDto;
import com.career_crafter.job_portal.entity.Employer;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserRestController {
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody User request) {
	    String email = request.getEmail();
	    String password = request.getPassword();

	    User user = userRepository.findByEmailAndPassword(email, password);

	    if (user != null) {
	        user.setPassword(null); // Don't send back password!
	        return ResponseEntity.ok(user);
	    } else {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
	    }
	}

    @Autowired
    private EmployerRepository employerRepository;
    
	@PostMapping("/register")
	public ResponseEntity<?> register(@RequestBody RegisterRequestDto request) {
	    if (userRepository.existsByEmail(request.getEmail())) {
	        return ResponseEntity
	                .status(HttpStatus.CONFLICT)
	                .body("Email already exists");
	    }

	    // ✅ Create and save User
	    User newUser = new User();
	    newUser.setName(request.getName());
	    newUser.setEmail(request.getEmail());
	    newUser.setPassword(request.getPassword());
	    newUser.setRole(request.getRole().toUpperCase());

	    userRepository.save(newUser);

	    // ✅ If role is ADMIN or EMPLOYER, create Employer
	    if ("ADMIN".equalsIgnoreCase(newUser.getRole()) || "EMPLOYER".equalsIgnoreCase(newUser.getRole())) {
	        Employer employer = new Employer();
	        employer.setUser(newUser);
	        employer.setCompanyName(request.getCompanyName() != null ? request.getCompanyName() : "Default Company");
	        employer.setLocation(request.getLocation() != null ? request.getLocation() : "Default Location");
	        employer.setWebsite(request.getWebsite() != null ? request.getWebsite() : "https://default.com");

	        employerRepository.save(employer);
	    }

	    return ResponseEntity
	            .status(HttpStatus.CREATED)
	            .body(newUser);
	}



    @Autowired
    private UserRepository userRepository;

    @GetMapping
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<User> getUserById(@PathVariable Long id) {
        return userRepository.findById(id);
    }

    @PostMapping
    public User createUser(@RequestBody User user) {
        return userRepository.save(user);
    }

    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User updatedUser) {
        updatedUser.setId(id);
        return userRepository.save(updatedUser);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
    }
}
