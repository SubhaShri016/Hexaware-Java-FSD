package com.career_crafter.job_portal.repository;

import com.career_crafter.job_portal.entity.Application;
import com.career_crafter.job_portal.entity.JobSeeker;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByJobSeekerId(Long jobSeekerId);
    @Query("SELECT a FROM Application a JOIN FETCH a.job j JOIN FETCH j.employer e WHERE e.user.id = :employerId")
    List<Application> findByEmployerId(@Param("employerId") Long employerId);

	List<Application> findByJobSeeker(JobSeeker jobSeeker);
	void deleteByJobId(Long id);

}
