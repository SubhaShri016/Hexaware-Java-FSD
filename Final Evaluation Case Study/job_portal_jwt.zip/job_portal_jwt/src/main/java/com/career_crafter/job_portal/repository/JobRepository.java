package com.career_crafter.job_portal.repository;

import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.entity.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface JobRepository extends JpaRepository<Job, Long> {
   
    List<Job> findByEmployer(Employer employer); // ✅ Corrected method
    List<Job> findByTitleContainingIgnoreCase(String title);

    // ✅ CORRECT: Search by Job.title, Job.location, Employer.companyName
    @Query("SELECT j FROM Job j JOIN j.employer e " +
           "WHERE LOWER(j.title) LIKE LOWER(CONCAT('%', :title, '%')) " +
           "AND LOWER(j.location) LIKE LOWER(CONCAT('%', :location, '%')) " +
           "AND LOWER(e.companyName) LIKE LOWER(CONCAT('%', :companyName, '%'))")
    List<Job> searchJobs(
            @Param("title") String title,
            @Param("location") String location,
            @Param("companyName") String companyName
    );
    
    
}
