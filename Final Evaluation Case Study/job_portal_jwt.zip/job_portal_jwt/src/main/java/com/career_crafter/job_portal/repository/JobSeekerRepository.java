package com.career_crafter.job_portal.repository;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobSeekerRepository extends JpaRepository<JobSeeker, Long> {

    JobSeeker findByUser(User user);

    // ✅ ADD THIS for stateless:
    JobSeeker findByUserId(Long userId);

}
