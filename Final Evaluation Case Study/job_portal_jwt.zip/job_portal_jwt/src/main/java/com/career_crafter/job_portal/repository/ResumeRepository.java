package com.career_crafter.job_portal.repository;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.Resume;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ResumeRepository extends JpaRepository<Resume, Long> {
    Optional<Resume> findByJobSeeker(JobSeeker jobSeeker);
    Resume findTopByJobSeekerOrderByUploadedAtDesc(JobSeeker jobSeeker);
}


