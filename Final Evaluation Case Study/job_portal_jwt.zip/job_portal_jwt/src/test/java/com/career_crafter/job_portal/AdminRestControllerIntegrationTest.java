/**package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.Application;
import com.career_crafter.job_portal.entity.Job;
import com.career_crafter.job_portal.repository.ApplicationRepository;
import com.career_crafter.job_portal.repository.JobRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class AdminRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        applicationRepository.deleteAll();
        jobRepository.deleteAll();
    }

    @Test
    void testCreateJob() throws Exception {
        Job job = new Job();
        job.setTitle("Java Developer");
        job.setDescription("Full-time Java backend developer");
        job.setLocation("Chennai");
        job.setQualifications("B.E CSE");

        mockMvc.perform(post("/api/admin/jobs")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(job)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Java Developer"))
                .andExpect(jsonPath("$.location").value("Chennai"));
    }

    @Test
    void testGetAllJobs() throws Exception {
        Job job1 = new Job();
        job1.setTitle("Frontend Dev");
        job1.setDescription("React Dev");
        job1.setLocation("Bangalore");
        job1.setQualifications("B.Tech");

        Job job2 = new Job();
        job2.setTitle("Backend Dev");
        job2.setDescription("Spring Boot Dev");
        job2.setLocation("Hyderabad");
        job2.setQualifications("MCA");

        jobRepository.save(job1);
        jobRepository.save(job2);

        mockMvc.perform(get("/api/admin/jobs"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].title", is("Frontend Dev")))
                .andExpect(jsonPath("$[1].title", is("Backend Dev")));
    }

    @Test
    void testDeleteJob() throws Exception {
        Job job = new Job();
        job.setTitle("Temp Job");
        job.setDescription("To be deleted");
        job.setLocation("Delhi");
        job.setQualifications("None");

        Job saved = jobRepository.save(job);

        mockMvc.perform(delete("/api/admin/jobs/{id}", saved.getId()))
                .andExpect(status().isOk());

        mockMvc.perform(get("/api/admin/jobs"))
                .andExpect(jsonPath("$", hasSize(0)));
    }

    @Test
    void testGetAllApplications() throws Exception {
        Application app1 = new Application();
        app1.setStatus("Pending");

        Application app2 = new Application();
        app2.setStatus("Pending");

        applicationRepository.save(app1);
        applicationRepository.save(app2);

        mockMvc.perform(get("/api/admin/applications"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    @Test
    void testUpdateApplicationStatus() throws Exception {
        Application application = new Application();
        application.setStatus("Pending");

        Application saved = applicationRepository.save(application);

        mockMvc.perform(put("/api/admin/applications/{id}?status=Approved", saved.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("Approved"));
    }
}
*/


package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.Application;
import com.career_crafter.job_portal.entity.Job;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.ApplicationRepository;
import com.career_crafter.job_portal.repository.JobRepository;
import com.career_crafter.job_portal.repository.UserRepository;
import com.career_crafter.job_portal.security.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import javax.sql.DataSource;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class AdminRestControllerIntegrationTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private JobRepository jobRepository;
    @Autowired private ApplicationRepository applicationRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private ObjectMapper objectMapper;

    // ✅ Add this to debug which DB is used
    @Autowired private DataSource dataSource;

    private String jwtToken;

    @BeforeEach
    void setUp() throws Exception {
        // ✅ Debug print to see which DB is actually used
        System.out.println("### ACTUAL DB URL: " + dataSource.getConnection().getMetaData().getURL());

        applicationRepository.deleteAll();
        jobRepository.deleteAll();
        userRepository.deleteAll();

        User adminUser = new User();
        adminUser.setName("Admin");
        adminUser.setEmail("admin@test.com");
        adminUser.setPassword("pass");
        adminUser.setRole("ADMIN");
        userRepository.save(adminUser);

        jwtToken = jwtUtil.generateToken(adminUser);
    }

    @Test
    void testCreateJob() throws Exception {
        Job job = new Job();
        job.setTitle("Java Developer");
        job.setDescription("Full-time Java backend developer");
        job.setLocation("Chennai");
        job.setQualifications("B.E CSE");

        mockMvc.perform(post("/api/admin/jobs")
                .header("Authorization", "Bearer " + jwtToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(job)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Java Developer"))
                .andExpect(jsonPath("$.location").value("Chennai"));
    }

    @Test
    void testGetAllJobs() throws Exception {
        Job job1 = new Job();
        job1.setTitle("Frontend Dev");
        job1.setDescription("React Dev");
        job1.setLocation("Bangalore");
        job1.setQualifications("B.Tech");

        Job job2 = new Job();
        job2.setTitle("Backend Dev");
        job2.setDescription("Spring Boot Dev");
        job2.setLocation("Hyderabad");
        job2.setQualifications("MCA");

        jobRepository.save(job1);
        jobRepository.save(job2);

        mockMvc.perform(get("/api/admin/jobs")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].title", is("Frontend Dev")))
                .andExpect(jsonPath("$[1].title", is("Backend Dev")));
    }

    @Test
    void testDeleteJob() throws Exception {
        Job job = new Job();
        job.setTitle("Temp Job");
        job.setDescription("To be deleted");
        job.setLocation("Delhi");
        job.setQualifications("None");

        Job saved = jobRepository.save(job);

        mockMvc.perform(delete("/api/admin/jobs/{id}", saved.getId())
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk());

        mockMvc.perform(get("/api/admin/jobs")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(jsonPath("$", hasSize(0)));
    }

    @Test
    void testGetAllApplications() throws Exception {
        Application app1 = new Application();
        app1.setStatus("Pending");

        Application app2 = new Application();
        app2.setStatus("Pending");

        applicationRepository.save(app1);
        applicationRepository.save(app2);

        mockMvc.perform(get("/api/admin/applications")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    @Test
    void testUpdateApplicationStatus() throws Exception {
        Application application = new Application();
        application.setStatus("Pending");

        Application saved = applicationRepository.save(application);

        mockMvc.perform(put("/api/admin/applications/{id}?status=Approved", saved.getId())
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("Approved"));
    }
}


