/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
class ApplicationRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    void setup() {
        // Delete in order: Applications -> Jobs -> JobSeekers -> Users
        applicationRepository.deleteAll();
        jobRepository.deleteAll();
        jobSeekerRepository.deleteAll();
        userRepository.deleteAll();
    }

    @Test
    void testCreateAndGetApplication() throws Exception {
        // Create User for JobSeeker
        User user = new User();
        user.setName("Alice");
        user.setEmail("alice@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        JobSeeker js = new JobSeeker();
        js.setUser(user);
        jobSeekerRepository.save(js);

        // Create Job
        User empUser = new User();
        empUser.setName("Employer");
        empUser.setEmail("employer@example.com");
        empUser.setPassword("pass");
        empUser.setRole("EMPLOYER");
        userRepository.save(empUser);

        Employer emp = new Employer();
        emp.setUser(empUser);
        emp.setCompanyName("Tech Corp");

        Job job = new Job();
        job.setTitle("Java Dev");
        job.setEmployer(emp);
        jobRepository.save(job);

        String json = """
            {
              "job": { "id": %d },
              "jobSeeker": { "id": %d },
              "resumePath": "uploads/resume.pdf",
              "status": "APPLIED"
            }
        """.formatted(job.getId(), js.getId());

        mockMvc.perform(post("/api/applications")
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("APPLIED"));

        Application saved = applicationRepository.findAll().get(0);
        assertThat(saved).isNotNull();
        assertThat(saved.getJob().getId()).isEqualTo(job.getId());
        assertThat(saved.getJobSeeker().getId()).isEqualTo(js.getId());

        mockMvc.perform(get("/api/applications/" + saved.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("APPLIED"));
    }

    @Test
    void testUpdateAndDeleteApplication() throws Exception {
        // Setup basic app
        User user = new User();
        user.setName("Bob");
        user.setEmail("bob@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        JobSeeker js = new JobSeeker();
        js.setUser(user);
        jobSeekerRepository.save(js);

        Job job = new Job();
        job.setTitle("Python Dev");
        Employer emp = new Employer();
        emp.setUser(user);
        emp.setCompanyName("CodeHouse");
        job.setEmployer(emp);
        jobRepository.save(job);

        Application app = new Application();
        app.setJob(job);
        app.setJobSeeker(js);
        app.setStatus("APPLIED");
        app.setResumePath("uploads/old.pdf");
        applicationRepository.save(app);

        String json = """
            {
              "job": { "id": %d },
              "jobSeeker": { "id": %d },
              "resumePath": "uploads/updated.pdf",
              "status": "INTERVIEW"
            }
        """.formatted(job.getId(), js.getId());

        mockMvc.perform(put("/api/applications/" + app.getId())
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("INTERVIEW"));

        Application updated = applicationRepository.findById(app.getId()).orElseThrow();
        assertThat(updated.getStatus()).isEqualTo("INTERVIEW");

        // Delete safely
        mockMvc.perform(delete("/api/applications/" + app.getId()))
                .andExpect(status().isOk());

        assertThat(applicationRepository.findById(app.getId())).isEmpty();
    }
}
*/



package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;
import com.career_crafter.job_portal.security.JwtUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.sql.Connection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
class ApplicationRestControllerIntegrationTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ApplicationRepository applicationRepository;
    @Autowired private JobRepository jobRepository;
    @Autowired private JobSeekerRepository jobSeekerRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private EmployerRepository employerRepository;
    @Autowired private DataSource dataSource;
    @Autowired private JwtUtil jwtUtil;

    private String jwtToken;

    @BeforeEach
    void setup() throws Exception {
        // ✅ Print actual DB URL to verify H2 in use
        try (Connection conn = dataSource.getConnection()) {
            System.out.println("### ACTUAL DB URL: " + conn.getMetaData().getURL());
        }

        // Delete in proper order
        applicationRepository.deleteAll();
        jobRepository.deleteAll();
        jobSeekerRepository.deleteAll();
        employerRepository.deleteAll();
        userRepository.deleteAll();

        // ✅ Create test User & JWT
        User testUser = new User();
        testUser.setName("Alice");
        testUser.setEmail("alice@example.com");
        testUser.setPassword("pass");
        testUser.setRole("USER");
        userRepository.save(testUser);

        jwtToken = jwtUtil.generateToken(testUser);
    }

    @Test
    void testCreateAndGetApplication() throws Exception {
        User user = userRepository.findByEmail("alice@example.com").orElseThrow();

        JobSeeker js = new JobSeeker();
        js.setUser(user);
        jobSeekerRepository.save(js);

        // Create Employer User
        User empUser = new User();
        empUser.setName("Employer");
        empUser.setEmail("employer@example.com");
        empUser.setPassword("pass");
        empUser.setRole("EMPLOYER");
        userRepository.save(empUser);

        Employer emp = new Employer();
        emp.setUser(empUser);
        emp.setCompanyName("Tech Corp");
        employerRepository.save(emp);

        // Create Job
        Job job = new Job();
        job.setTitle("Java Dev");
        job.setEmployer(emp);
        jobRepository.save(job);

        String json = """
            {
              "job": { "id": %d },
              "jobSeeker": { "id": %d },
              "resumePath": "uploads/resume.pdf",
              "status": "APPLIED"
            }
        """.formatted(job.getId(), js.getId());

        mockMvc.perform(post("/api/applications")
                .header("Authorization", "Bearer " + jwtToken)
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("APPLIED"));

        Application saved = applicationRepository.findAll().get(0);
        assertThat(saved).isNotNull();
        assertThat(saved.getJob().getId()).isEqualTo(job.getId());
        assertThat(saved.getJobSeeker().getId()).isEqualTo(js.getId());

        mockMvc.perform(get("/api/applications/" + saved.getId())
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("APPLIED"));
    }

    @Test
    void testUpdateAndDeleteApplication() throws Exception {
        User user = userRepository.findByEmail("alice@example.com").orElseThrow();

        JobSeeker js = new JobSeeker();
        js.setUser(user);
        jobSeekerRepository.save(js);

        Employer emp = new Employer();
        emp.setUser(user);
        emp.setCompanyName("CodeHouse");
        employerRepository.save(emp);

        Job job = new Job();
        job.setTitle("Python Dev");
        job.setEmployer(emp);
        jobRepository.save(job);

        Application app = new Application();
        app.setJob(job);
        app.setJobSeeker(js);
        app.setStatus("APPLIED");
        app.setResumePath("uploads/old.pdf");
        applicationRepository.save(app);

        String json = """
            {
              "job": { "id": %d },
              "jobSeeker": { "id": %d },
              "resumePath": "uploads/updated.pdf",
              "status": "INTERVIEW"
            }
        """.formatted(job.getId(), js.getId());

        mockMvc.perform(put("/api/applications/" + app.getId())
                .header("Authorization", "Bearer " + jwtToken)
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("INTERVIEW"));

        Application updated = applicationRepository.findById(app.getId()).orElseThrow();
        assertThat(updated.getStatus()).isEqualTo("INTERVIEW");

        mockMvc.perform(delete("/api/applications/" + app.getId())
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk());

        assertThat(applicationRepository.findById(app.getId())).isEmpty();
    }
}
