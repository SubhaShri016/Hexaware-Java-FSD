package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.EmployerRepository;
import com.career_crafter.job_portal.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
public class EmployerRepositoryTest {

    @Autowired
    private EmployerRepository employerRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    public void testSaveEmployer() {
      
        User user = new User();
        user.setName("Test User");
        user.setEmail("testuser@example.com");
        user.setPassword("test123");
        user.setRole("EMPLOYER");

        userRepository.save(user);

        // Now create and save Employer using that user
        Employer employer = new Employer();
        employer.setUser(user);
        employer.setCompanyName("Test Corp");
        employer.setLocation("Chennai");
        employer.setWebsite("https://testcorp.com");

        employerRepository.save(employer);
    }
}
