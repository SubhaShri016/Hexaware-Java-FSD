/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.repository.EmployerRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class EmployerRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private EmployerRepository employerRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        employerRepository.deleteAll();
    }

    @Test
    void testCreateEmployer() throws Exception {
        Employer employer = new Employer();
        employer.setCompanyName("OpenAI");
        employer.setLocation("San Francisco");
        employer.setWebsite("https://openai.com");

        mockMvc.perform(post("/api/employers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(employer)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.companyName").value("OpenAI"));
    }

    @Test
    void testGetAllEmployers() throws Exception {
        Employer emp1 = new Employer();
        emp1.setCompanyName("A");
        emp1.setLocation("X");
        emp1.setWebsite("a.com");

        Employer emp2 = new Employer();
        emp2.setCompanyName("B");
        emp2.setLocation("Y");
        emp2.setWebsite("b.com");

        employerRepository.save(emp1);
        employerRepository.save(emp2);

        mockMvc.perform(get("/api/employers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    @Test
    void testGetEmployerById() throws Exception {
        Employer emp = new Employer();
        emp.setCompanyName("FindMe");
        emp.setLocation("Remote");
        emp.setWebsite("findme.com");

        Employer saved = employerRepository.save(emp);

        mockMvc.perform(get("/api/employers/{id}", saved.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.companyName").value("FindMe"));
    }

    @Test
    void testUpdateEmployer() throws Exception {
        Employer emp = new Employer();
        emp.setCompanyName("Old Name");
        emp.setLocation("Old City");
        emp.setWebsite("old.com");

        Employer saved = employerRepository.save(emp);

        saved.setCompanyName("New Name");
        saved.setLocation("New City");

        mockMvc.perform(put("/api/employers/{id}", saved.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(saved)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.companyName").value("New Name"))
                .andExpect(jsonPath("$.location").value("New City"));
    }

    @Test
    void testDeleteEmployer_SuccessAndNotFound() throws Exception {
        Employer employer = new Employer();
        employer.setCompanyName("Test Company");
        Employer saved = employerRepository.save(employer);

        mockMvc.perform(delete("/api/employers/{id}", saved.getId()))
                .andExpect(status().isOk()); // ✅ matches controller

        mockMvc.perform(delete("/api/employers/{id}", saved.getId()))
                .andExpect(status().isOk()); // ✅ still matches controller
    }

}
*/
package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.EmployerRepository;
import com.career_crafter.job_portal.repository.UserRepository;
import com.career_crafter.job_portal.security.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class EmployerRestControllerIntegrationTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private EmployerRepository employerRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private ObjectMapper objectMapper;

    private User employerUser;
    private String jwtToken;

    @BeforeEach
    void setUp() {
        employerRepository.deleteAll();
        userRepository.deleteAll();

        employerUser = new User();
        employerUser.setName("Employer User");
        employerUser.setEmail("employer@test.com");
        employerUser.setPassword("pass");
        employerUser.setRole("EMPLOYER");
        userRepository.save(employerUser);

        jwtToken = jwtUtil.generateToken(employerUser);
    }

    @Test
    void testCreateEmployer() throws Exception {
        Employer employer = new Employer();
        employer.setCompanyName("OpenAI");
        employer.setLocation("San Francisco");
        employer.setWebsite("https://openai.com");

        mockMvc.perform(post("/api/employers")
                        .header("Authorization", "Bearer " + jwtToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(employer)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.companyName").value("OpenAI"));
    }

    @Test
    void testGetAllEmployers() throws Exception {
        Employer emp1 = new Employer();
        emp1.setCompanyName("A");
        emp1.setLocation("X");
        emp1.setWebsite("a.com");

        Employer emp2 = new Employer();
        emp2.setCompanyName("B");
        emp2.setLocation("Y");
        emp2.setWebsite("b.com");

        employerRepository.save(emp1);
        employerRepository.save(emp2);

        mockMvc.perform(get("/api/employers")
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)));
    }

    @Test
    void testGetEmployerById() throws Exception {
        Employer emp = new Employer();
        emp.setCompanyName("FindMe");
        emp.setLocation("Remote");
        emp.setWebsite("findme.com");

        Employer saved = employerRepository.save(emp);

        mockMvc.perform(get("/api/employers/{id}", saved.getId())
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.companyName").value("FindMe"));
    }

    @Test
    void testUpdateEmployer() throws Exception {
        Employer emp = new Employer();
        emp.setCompanyName("Old Name");
        emp.setLocation("Old City");
        emp.setWebsite("old.com");

        Employer saved = employerRepository.save(emp);

        saved.setCompanyName("New Name");
        saved.setLocation("New City");

        mockMvc.perform(put("/api/employers/{id}", saved.getId())
                        .header("Authorization", "Bearer " + jwtToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(saved)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.companyName").value("New Name"))
                .andExpect(jsonPath("$.location").value("New City"));
    }

    @Test
    void testDeleteEmployer_SuccessAndNotFound() throws Exception {
        Employer employer = new Employer();
        employer.setCompanyName("Test Company");
        Employer saved = employerRepository.save(employer);

        mockMvc.perform(delete("/api/employers/{id}", saved.getId())
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk());

        mockMvc.perform(delete("/api/employers/{id}", saved.getId())
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk()); // your controller returns OK even if not found
    }

}
