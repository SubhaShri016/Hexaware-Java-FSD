/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;

import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.Mockito.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
public class JobControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean private JobRepository jobRepository;
    @MockBean private EmployerRepository employerRepository;
    @MockBean private ApplicationRepository applicationRepository;
    @MockBean private ResumeRepository resumeRepository;

    @Test
    void testAddJob_Unauthorized() throws Exception {
        mockMvc.perform(post("/jobs/add")
                .param("title", "Java Dev")
                .param("description", "Spring")
                .param("location", "Remote")
                .param("qualifications", "Java"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }

    @Test
    void testAddJob_AsEmployer() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setRole("ADMIN");

        Employer employer = new Employer();
        employer.setId(1L);

        when(employerRepository.findByUserId(1L)).thenReturn(employer);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", user);

        mockMvc.perform(post("/jobs/add")
                .session(session)
                .param("title", "Java Dev")
                .param("description", "Spring")
                .param("location", "Remote")
                .param("qualifications", "Java"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    void testMyJobs_AsEmployer() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setRole("ADMIN");

        Employer employer = new Employer();
        employer.setId(1L);

        when(employerRepository.findByUserId(1L)).thenReturn(employer);
        when(jobRepository.findByEmployer(employer)).thenReturn(Collections.emptyList());

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", user);

        mockMvc.perform(get("/jobs/employer/myjobs")
                .session(session))
                .andExpect(status().isOk());
    }

    @Test
    void testViewApplications_AsEmployer() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setRole("ADMIN");

        when(applicationRepository.findByEmployerId(1L)).thenReturn(Collections.emptyList());

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", user);

        mockMvc.perform(get("/jobs/employer/applications")
                .session(session))
                .andExpect(status().isOk());
    }
}*/

package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.*;
import com.career_crafter.job_portal.security.JwtUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
public class JobControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean private JobRepository jobRepository;
    @MockBean private EmployerRepository employerRepository;
    @MockBean private ApplicationRepository applicationRepository;
    @MockBean private ResumeRepository resumeRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private String jwtToken;

    private User employerUser;

    @BeforeEach
    void setup() {
        employerUser = new User();
        employerUser.setId(1L);
        employerUser.setEmail("employer@test.com");
        employerUser.setRole("EMPLOYER");

        jwtToken = jwtUtil.generateToken(employerUser);
    }

    @Test
    void testAddJob_Unauthorized() throws Exception {
        mockMvc.perform(post("/jobs/add")
                .param("title", "Java Dev")
                .param("description", "Spring")
                .param("location", "Remote")
                .param("qualifications", "Java"))
                .andExpect(status().isForbidden());
    }

    @Test
    void testAddJob_AsEmployer() throws Exception {
        Employer employer = new Employer();
        employer.setId(1L);

        when(employerRepository.findByUserId(1L)).thenReturn(employer);

        mockMvc.perform(post("/jobs/add")
                .header("Authorization", "Bearer " + jwtToken)
                .param("title", "Java Dev")
                .param("description", "Spring")
                .param("location", "Remote")
                .param("qualifications", "Java"))
                .andExpect(status().is3xxRedirection());
    }

    @Test
    void testMyJobs_AsEmployer() throws Exception {
        Employer employer = new Employer();
        employer.setId(1L);

        when(employerRepository.findByUserId(1L)).thenReturn(employer);
        when(jobRepository.findByEmployer(employer)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/jobs/employer/myjobs")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk());
    }

    @Test
    void testViewApplications_AsEmployer() throws Exception {
        when(applicationRepository.findByEmployerId(1L)).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/jobs/employer/applications")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk());
    }
}

