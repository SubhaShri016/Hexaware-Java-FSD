/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;
import com.career_crafter.job_portal.service.MailService;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
public class JobRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean private JobRepository jobRepository;
    @MockBean private EmployerRepository employerRepository;
    @MockBean private ApplicationRepository applicationRepository;
    @MockBean private ResumeRepository resumeRepository;
    @MockBean private UserRepository userRepository;
    @MockBean private MailService mailService;

    @Test
    void testGetAllJobs() throws Exception {
        when(jobRepository.findAll()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/jobs"))
                .andExpect(status().isOk());
    }

    @Test
    void testGetJobById_NotFound() throws Exception {
        when(jobRepository.findById(1L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/jobs/1"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testPostJobForEmployer_Success() throws Exception {
        User user = new User();
        user.setId(1L);
        user.setRole("ADMIN");
        user.setEmail("test@example.com");
        user.setName("Test Employer");

        Employer employer = new Employer();
        employer.setId(1L);

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(employerRepository.findByUserId(1L)).thenReturn(employer);
        when(jobRepository.save(any(Job.class))).thenAnswer(i -> i.getArgument(0));

        String jobJson = """
            {
                "title": "Java Developer",
                "description": "Spring Boot Dev",
                "location": "Remote",
                "qualifications": "Java"
            }
        """;

        mockMvc.perform(post("/api/jobs/employer")
                .param("userId", "1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jobJson))
                .andExpect(status().isCreated());

        // Verify email was sent
        verify(mailService, times(1)).sendMail(eq("test@example.com"), anyString(), contains("Java Developer"));
    }

    @Test
    void testDeleteJob_NotFound() throws Exception {
        when(jobRepository.existsById(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/jobs/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testSearchJobs() throws Exception {
        when(jobRepository.searchJobs(anyString(), anyString(), anyString())).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/jobs/search")
                .param("title", "Java"))
                .andExpect(status().isOk());
    }
}
*/
package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.*;
import com.career_crafter.job_portal.security.JwtUtil;
import com.career_crafter.job_portal.service.MailService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;
import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class JobRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private JwtUtil jwtUtil;

    @MockBean private JobRepository jobRepository;
    @MockBean private EmployerRepository employerRepository;
    @MockBean private ApplicationRepository applicationRepository;
    @MockBean private ResumeRepository resumeRepository;
    @MockBean private UserRepository userRepository;
    @MockBean private MailService mailService;

    private String jwtToken;

    private User adminUser;

    @BeforeEach
    void setup() {
        // ✅ Make sure the role matches your controller: your POST job logic expects ADMIN
        adminUser = new User();
        adminUser.setId(1L);
        adminUser.setEmail("admin@example.com");
        adminUser.setRole("ADMIN");  // ✅ Your controller checks for ADMIN for /employer POST
        adminUser.setName("Admin User");

        jwtToken = jwtUtil.generateToken(adminUser);
    }

    @Test
    void testGetAllJobs() throws Exception {
        when(jobRepository.findAll()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/jobs")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk());
    }

    @Test
    void testGetJobById_NotFound() throws Exception {
        when(jobRepository.findById(1L)).thenReturn(Optional.empty());

        mockMvc.perform(get("/api/jobs/1")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isNotFound());
    }

    @Test
    void testPostJobForEmployer_Success() throws Exception {
        // ✅ Must match controller flow: 1) find user by ID, 2) role must be ADMIN, 3) employer must exist
        when(userRepository.findById(1L)).thenReturn(Optional.of(adminUser));

        Employer employer = new Employer();
        employer.setId(1L);
        when(employerRepository.findByUserId(1L)).thenReturn(employer);

        when(jobRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        String jobJson = """
            {
                "title": "Backend Developer",
                "description": "Build REST APIs",
                "location": "Remote",
                "qualifications": "Java, Spring Boot"
            }
        """;

        mockMvc.perform(post("/api/jobs/employer")
                .param("userId", "1") // ✅ This param must match the user ID you mocked
                .header("Authorization", "Bearer " + jwtToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jobJson))
                .andExpect(status().isCreated());

        verify(mailService, times(1))
                .sendMail(eq("admin@example.com"), anyString(), contains("Backend Developer"));
    }

    @Test
    void testDeleteJob_NotFound() throws Exception {
        when(jobRepository.existsById(99L)).thenReturn(false);

        mockMvc.perform(delete("/api/jobs/99")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isNotFound());
    }

    @Test
    void testSearchJobs() throws Exception {
        when(jobRepository.searchJobs(anyString(), anyString(), anyString()))
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/jobs/search")
                .param("title", "Java")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk());
    }
}
