/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.UserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@AutoConfigureMockMvc
@SpringBootTest(properties = "spring.profiles.active=test")
class JobSeekerControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    private User user;
    private MockHttpSession session;

    @BeforeEach
    void setUp() {
        // ✅ First delete child table to avoid FK constraint violation
        jobSeekerRepository.deleteAll();
        // ✅ Then delete parent table
        userRepository.deleteAll();

        // ✅ Insert fresh user for each test
        user = new User();
        user.setName("Test User");
        user.setEmail("test@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        // ✅ Mock session with user
        session = new MockHttpSession();
        session.setAttribute("user", user);
    }

    @Test
    void testProfileForm_WithSession_ShouldForwardToProfilePage() throws Exception {
        mockMvc.perform(get("/jobseeker/profile").session(session))
                .andExpect(status().isOk())
                .andExpect(forwardedUrl("/jobseeker_profile.jsp"));
    }

    @Test
    void testSaveProfile_AndViewProfile() throws Exception {
        mockMvc.perform(post("/jobseeker/profile/save")
                        .session(session)
                        .param("fullName", "John Doe")
                        .param("phone", "1234567890")
                        .param("education", "Bachelor")
                        .param("experience", "2 years")
                        .param("skills", "Java, Spring"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/jobseeker/profile/view"));

        // ✅ Verify saved profile
        JobSeeker saved = jobSeekerRepository.findByUser(user);
        assertThat(saved).isNotNull();
        assertThat(saved.getFullName()).isEqualTo("John Doe");

        // ✅ View profile
        mockMvc.perform(get("/jobseeker/profile/view").session(session))
                .andExpect(status().isOk())
                .andExpect(forwardedUrl("/jobseeker_view_profile.jsp"));
    }

    @Test
    void testRedirectToLogin_WhenNoSession() throws Exception {
        mockMvc.perform(get("/jobseeker/profile"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }
}
*/
package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.UserRepository;
import com.career_crafter.job_portal.security.JwtUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@AutoConfigureMockMvc
@SpringBootTest(properties = "spring.profiles.active=test")
class JobSeekerControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private User user;
    private MockHttpSession session;
    private String jwtToken;

    @BeforeEach
    void setUp() {
        jobSeekerRepository.deleteAll();
        userRepository.deleteAll();

        user = new User();
        user.setName("Test User");
        user.setEmail("test@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        jwtToken = jwtUtil.generateToken(user);

        session = new MockHttpSession();
        session.setAttribute("user", user);
    }

    @Test
    void testProfileForm_WithSession_ShouldForwardToProfilePage() throws Exception {
        mockMvc.perform(get("/jobseeker/profile")
                        .session(session)
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(forwardedUrl("/jobseeker_profile.jsp"));
    }

    @Test
    void testSaveProfile_AndViewProfile() throws Exception {
        mockMvc.perform(post("/jobseeker/profile/save")
                        .session(session)
                        .header("Authorization", "Bearer " + jwtToken)
                        .param("fullName", "John Doe")
                        .param("phone", "1234567890")
                        .param("education", "Bachelor")
                        .param("experience", "2 years")
                        .param("skills", "Java, Spring"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/jobseeker/profile/view"));

        JobSeeker saved = jobSeekerRepository.findByUser(user);
        assertThat(saved).isNotNull();
        assertThat(saved.getFullName()).isEqualTo("John Doe");

        mockMvc.perform(get("/jobseeker/profile/view")
                        .session(session)
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(forwardedUrl("/jobseeker_view_profile.jsp"));
    }

    @Test
    void testRedirectToLogin_WhenNoSession() throws Exception {
        mockMvc.perform(get("/jobseeker/profile")
                        .header("Authorization", "Bearer " + jwtToken)) // ✅ valid JWT but NO session
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }
}
