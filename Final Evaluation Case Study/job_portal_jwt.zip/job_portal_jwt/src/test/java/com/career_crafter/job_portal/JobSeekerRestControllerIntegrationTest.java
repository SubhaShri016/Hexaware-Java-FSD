/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
class JobSeekerRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private EmployerRepository employerRepository; // ✅ Needed for safe FK cleanup

    @BeforeEach
    void setup() {
        // ✅ Correct order: child → parent
        applicationRepository.deleteAll();
        jobRepository.deleteAll();
        jobSeekerRepository.deleteAll();
        employerRepository.deleteAll();
        userRepository.deleteAll();
    }

    @Test
    void testCreateAndGetJobSeeker() throws Exception {
        // Arrange
        User user = new User();
        user.setName("Test User");
        user.setEmail("test@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        String json = """
            {
              "user": { "id": %d },
              "fullName": "John Doe",
              "phone": "1234567890",
              "education": "Bachelor",
              "experience": "2 years",
              "skills": "Java"
            }
        """.formatted(user.getId());

        // Act & Assert: create
        mockMvc.perform(post("/api/jobseekers")
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("John Doe"));

        JobSeeker saved = jobSeekerRepository.findAll().get(0);
        assertThat(saved).isNotNull();
        assertThat(saved.getUser().getId()).isEqualTo(user.getId());

        // Act & Assert: get
        mockMvc.perform(get("/api/jobseekers/" + saved.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("John Doe"));
    }

    @Test
    void testProfileSaveAndGet() throws Exception {
        // Arrange
        User user = new User();
        user.setName("Jane Doe");
        user.setEmail("jane@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        JobSeeker js = new JobSeeker();
        js.setUser(user);
        js.setFullName("Old Name");
        jobSeekerRepository.save(js);

        String json = """
            {
              "user": { "id": %d },
              "fullName": "Updated Name",
              "phone": "9999999999",
              "education": "Masters",
              "experience": "5 years",
              "skills": "Python"
            }
        """.formatted(user.getId());

        // Act & Assert: update profile
        mockMvc.perform(post("/api/jobseekers/profile")
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(content().string("Profile updated!"));

        JobSeeker updated = jobSeekerRepository.findByUser(user);
        assertThat(updated.getFullName()).isEqualTo("Updated Name");

        // Act & Assert: get profile
        mockMvc.perform(get("/api/jobseekers/profile?userId=" + user.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("Updated Name"));
    }

    @Test
    void testApplyJobAndMail() throws Exception {
        // Arrange: create job seeker user
        User user = new User();
        user.setName("Jake");
        user.setEmail("jake@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        JobSeeker js = new JobSeeker();
        js.setUser(user);
        jobSeekerRepository.save(js);

        // Arrange: create employer
        User employerUser = new User();
        employerUser.setName("Employer");
        employerUser.setEmail("employer@example.com");
        employerUser.setPassword("pass");
        employerUser.setRole("EMPLOYER");
        userRepository.save(employerUser);

        Employer emp = new Employer();
        emp.setUser(employerUser);
        emp.setCompanyName("TechCorp");
        employerRepository.save(emp); // ✅ Save employer correctly

        // Arrange: create job
        Job job = new Job();
        job.setTitle("Java Developer");
        job.setEmployer(emp);
        jobRepository.save(job);

        String json = """
            {
              "jobId": %d,
              "userId": %d
            }
        """.formatted(job.getId(), user.getId());

        // Act & Assert: apply
        mockMvc.perform(post("/api/jobseekers/apply")
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(content().string("Application submitted!"));

        assertThat(applicationRepository.findAll()).hasSize(1);
    }
}
*/

package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;
import com.career_crafter.job_portal.security.JwtUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
class JobSeekerRestControllerIntegrationTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private UserRepository userRepository;
    @Autowired private JobSeekerRepository jobSeekerRepository;
    @Autowired private JobRepository jobRepository;
    @Autowired private ApplicationRepository applicationRepository;
    @Autowired private EmployerRepository employerRepository;

    @Autowired private JwtUtil jwtUtil;

    private User user;
    private String jwtToken;

    @BeforeEach
    void setup() {
        // Clean DB in FK-safe order
        applicationRepository.deleteAll();
        jobRepository.deleteAll();
        jobSeekerRepository.deleteAll();
        employerRepository.deleteAll();
        userRepository.deleteAll();

        // Fresh user for tests
        user = new User();
        user.setName("Test User");
        user.setEmail("test@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        jwtToken = jwtUtil.generateToken(user);
    }

    @Test
    void testCreateAndGetJobSeeker() throws Exception {
        String json = """
            {
              "user": { "id": %d },
              "fullName": "John Doe",
              "phone": "1234567890",
              "education": "Bachelor",
              "experience": "2 years",
              "skills": "Java"
            }
        """.formatted(user.getId());

        // Create
        mockMvc.perform(post("/api/jobseekers")
                .header("Authorization", "Bearer " + jwtToken)
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("John Doe"));

        JobSeeker saved = jobSeekerRepository.findAll().get(0);
        assertThat(saved).isNotNull();
        assertThat(saved.getUser().getId()).isEqualTo(user.getId());

        // Get by ID
        mockMvc.perform(get("/api/jobseekers/" + saved.getId())
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("John Doe"));
    }

    @Test
    void testProfileSaveAndGet() throws Exception {
        // Save old profile
        JobSeeker js = new JobSeeker();
        js.setUser(user);
        js.setFullName("Old Name");
        jobSeekerRepository.save(js);

        String json = """
            {
              "user": { "id": %d },
              "fullName": "Updated Name",
              "phone": "9999999999",
              "education": "Masters",
              "experience": "5 years",
              "skills": "Python"
            }
        """.formatted(user.getId());

        // Save profile
        mockMvc.perform(post("/api/jobseekers/profile")
                .header("Authorization", "Bearer " + jwtToken)
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(content().string("Profile updated!"));

        JobSeeker updated = jobSeekerRepository.findByUser(user);
        assertThat(updated.getFullName()).isEqualTo("Updated Name");

        // Get profile
        mockMvc.perform(get("/api/jobseekers/profile")
                .param("userId", String.valueOf(user.getId()))
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fullName").value("Updated Name"));
    }

    @Test
    void testApplyJobAndMail() throws Exception {
        // Arrange: job seeker
        JobSeeker js = new JobSeeker();
        js.setUser(user);
        jobSeekerRepository.save(js);

        // Arrange: employer
        User employerUser = new User();
        employerUser.setName("Employer");
        employerUser.setEmail("employer@example.com");
        employerUser.setPassword("pass");
        employerUser.setRole("EMPLOYER");
        userRepository.save(employerUser);

        Employer emp = new Employer();
        emp.setUser(employerUser);
        emp.setCompanyName("TechCorp");
        employerRepository.save(emp);

        // Arrange: job
        Job job = new Job();
        job.setTitle("Java Developer");
        job.setEmployer(emp);
        jobRepository.save(job);

        String json = """
            {
              "jobId": %d,
              "userId": %d
            }
        """.formatted(job.getId(), user.getId());

        // Act: apply
        mockMvc.perform(post("/api/jobseekers/apply")
                .header("Authorization", "Bearer " + jwtToken)
                .contentType(APPLICATION_JSON)
                .content(json))
                .andExpect(status().isOk())
                .andExpect(content().string("Application submitted!"));

        assertThat(applicationRepository.findAll()).hasSize(1);
    }
}
