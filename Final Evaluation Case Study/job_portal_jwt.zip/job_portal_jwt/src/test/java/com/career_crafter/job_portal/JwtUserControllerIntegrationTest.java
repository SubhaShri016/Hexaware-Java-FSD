package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.UserRepository;
import com.career_crafter.job_portal.security.JwtUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class JwtUserControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    private String jwtToken;

    @BeforeEach
    void setup() {
        userRepository.deleteAll();

        // ✅ Add test user
        User user = new User();
        user.setName("TestUser");
        user.setEmail("testuser@example.com");
        user.setPassword("$2a$10$dummyhashedpassword"); // Should be hashed if your filter validates password, but here it’s fine.
        user.setRole("USER");
        userRepository.save(user);

        // ✅ Generate token for that user
        jwtToken = jwtUtil.generateToken(user);
    }

    @Test
    void testHello() throws Exception {
        mockMvc.perform(get("/api/user/hello")
                .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, you are authenticated with JWT!"));
    }

    @Test
    void testGetCurrentUser() throws Exception {
        mockMvc.perform(get("/api/user/me")
                .header("Authorization", "Bearer " + jwtToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("testuser@example.com"));
    }

    @Test
    void testUnauthorized_NoToken() throws Exception {
        mockMvc.perform(get("/api/user/hello"))
                .andExpect(status().isForbidden());
    }

    @Test
    void testUnauthorized_InvalidToken() throws Exception {
        mockMvc.perform(get("/api/user/hello")
                .header("Authorization", "Bearer invalid.token.here"))
                .andExpect(status().isForbidden());
    }
}
