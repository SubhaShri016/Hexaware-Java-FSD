/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.mock.web.MockHttpSession;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.career_crafter.job_portal.entity.User;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class MainControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Test
    void testIndexPage() throws Exception {
        mockMvc.perform(get("/"))
               .andExpect(status().isOk());
    }

    @Test
    void testLoginPageLoads() throws Exception {
        mockMvc.perform(get("/login"))
               .andExpect(status().isOk());
    }

    @Test
    void testRegisterPageLoads() throws Exception {
        mockMvc.perform(get("/register"))
               .andExpect(status().isOk());
    }

    @Test
    void testAdminHomeRedirectsWithoutSession() throws Exception {
        mockMvc.perform(get("/admin/home"))
               .andExpect(status().is3xxRedirection())
               .andExpect(redirectedUrl("/login"));
    }

    @Test
    void testUserHomeRedirectsWithoutSession() throws Exception {
        mockMvc.perform(get("/user/home"))
               .andExpect(status().is3xxRedirection())
               .andExpect(redirectedUrl("/login"));
    }

    @Test
    void testAdminHomeWithSession() throws Exception {
        // Create dummy admin user
        User user = new User();
        user.setName("Admin");
        user.setEmail("admin@example.com");
        user.setPassword("pass");
        user.setRole("ADMIN");
        userRepository.save(user);

        // Create session with user
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", user);

        mockMvc.perform(get("/admin/home").session(session))
               .andExpect(status().isOk());
    }

    @Test
    void testUserHomeWithSession() throws Exception {
        // Create dummy normal user
        User user = new User();
        user.setName("Test User");
        user.setEmail("testuser@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        // Create session with user
        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", user);

        mockMvc.perform(get("/user/home").session(session))
               .andExpect(status().isOk());
    }

    @Test
    void testRegistrationWithExistingEmailFails() throws Exception {
        // Save user
        User user = new User();
        user.setName("Existing User");
        user.setEmail("existing@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        mockMvc.perform(post("/register")
                .param("name", "New User")
                .param("email", "existing@example.com")
                .param("password", "pass")
                .param("role", "USER"))
               .andExpect(status().isOk())
               .andExpect(forwardedUrl("/registerpage.jsp"))
               .andExpect(model().attributeExists("message"));
    }

    @Test
    void testRegistrationSuccess() throws Exception {
        mockMvc.perform(post("/register")
                .param("name", "New User")
                .param("email", "newuser@example.com")
                .param("password", "pass")
                .param("role", "USER"))
               .andExpect(status().isOk())
               .andExpect(forwardedUrl("/loginpage.jsp"))
               .andExpect(model().attributeExists("message"));
    }

    @Test
    void testLoginSuccessUserRole() throws Exception {
        // Create user
        User user = new User();
        user.setName("Login User");
        user.setEmail("login@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        mockMvc.perform(post("/login")
                .param("email", "login@example.com")
                .param("password", "pass"))
               .andExpect(status().is3xxRedirection())
               .andExpect(redirectedUrl("/user/home"));
    }

    @Test
    void testLoginFailsInvalidCredentials() throws Exception {
        mockMvc.perform(post("/login")
                .param("email", "notfound@example.com")
                .param("password", "wrongpass"))
               .andExpect(status().isOk())
               .andExpect(forwardedUrl("/loginpage.jsp"))
               .andExpect(model().attributeExists("message"));
    }
}
*/


/*

package com.career_crafter.job_portal;

import com.career_crafter.job_portal.config.TestSecurityConfig;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.UserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Import(TestSecurityConfig.class) // ✅ Disables Spring Security for test
public class MainControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    void cleanDb() {
        userRepository.deleteAll();
    }

    @Test
    void indexPageLoads() throws Exception {
        mockMvc.perform(get("/"))
               .andExpect(status().isOk());
    }

    @Test
    void loginPageLoads() throws Exception {
        mockMvc.perform(get("/login"))
               .andExpect(status().isOk());
    }

    @Test
    void registerPageLoads() throws Exception {
        mockMvc.perform(get("/register"))
               .andExpect(status().isOk());
    }

    @Test
    void adminHomeRedirectsWithoutSession() throws Exception {
        mockMvc.perform(get("/admin/home"))
               .andExpect(status().is3xxRedirection())
               .andExpect(redirectedUrl("/login"));
    }

    @Test
    void userHomeRedirectsWithoutSession() throws Exception {
        mockMvc.perform(get("/user/home"))
               .andExpect(status().is3xxRedirection())
               .andExpect(redirectedUrl("/login"));
    }

    @Test
    void adminHomeLoadsWithSession() throws Exception {
        User admin = new User();
        admin.setName("Admin");
        admin.setEmail("admin@example.com");
        admin.setPassword("pass");
        admin.setRole("ADMIN");
        userRepository.save(admin);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", admin);

        mockMvc.perform(get("/admin/home").session(session))
               .andExpect(status().isOk());
    }

    @Test
    void userHomeLoadsWithSession() throws Exception {
        User user = new User();
        user.setName("User");
        user.setEmail("user@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", user);

        mockMvc.perform(get("/user/home").session(session))
               .andExpect(status().isOk());
    }

    @Test
    void registrationFailsIfEmailExists() throws Exception {
        User existing = new User();
        existing.setName("Existing");
        existing.setEmail("exist@example.com");
        existing.setPassword("pass");
        existing.setRole("USER");
        userRepository.save(existing);

        mockMvc.perform(post("/register")
                .param("name", "New User")
                .param("email", "exist@example.com")
                .param("password", "pass")
                .param("role", "USER"))
               .andExpect(status().isOk())
               .andExpect(forwardedUrl("/registerpage.jsp"))
               .andExpect(model().attributeExists("message"));
    }

    @Test
    void registrationSucceeds() throws Exception {
        mockMvc.perform(post("/register")
                .param("name", "New User")
                .param("email", "new@example.com")
                .param("password", "pass")
                .param("role", "USER"))
               .andExpect(status().isOk())
               .andExpect(forwardedUrl("/loginpage.jsp"))
               .andExpect(model().attributeExists("message"));

        assertThat(userRepository.findByEmailAndPassword("new@example.com", "pass")).isNotNull();
    }

    @Test
    void loginSuccessUser() throws Exception {
        User user = new User();
        user.setName("LoginUser");
        user.setEmail("login@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        mockMvc.perform(post("/login")
                .param("email", "login@example.com")
                .param("password", "pass"))
               .andExpect(status().is3xxRedirection())
               .andExpect(redirectedUrl("/user/home"));
    }

    @Test
    void loginFailsInvalidCredentials() throws Exception {
        mockMvc.perform(post("/login")
                .param("email", "wrong@example.com")
                .param("password", "wrongpass"))
               .andExpect(status().isOk())
               .andExpect(forwardedUrl("/loginpage.jsp"))
               .andExpect(model().attributeExists("message"));
    }

    @Test
    void logoutInvalidatesSession() throws Exception {
        User user = new User();
        user.setName("TestUser");
        user.setEmail("test@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("user", user);

        mockMvc.perform(get("/logout").session(session))
               .andExpect(status().is3xxRedirection())
               .andExpect(redirectedUrl("/login"));

        assertThat(session.isInvalid()).isTrue();
    }
}
*/