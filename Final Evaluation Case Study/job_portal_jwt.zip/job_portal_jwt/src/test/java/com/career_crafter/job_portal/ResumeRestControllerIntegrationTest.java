/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
class ResumeRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    void cleanUp() throws Exception {
        resumeRepository.deleteAll();
        jobSeekerRepository.deleteAll();
        userRepository.deleteAll();

        // Clear test uploads dir if any
        Path uploadDir = Path.of("uploads");
        if (Files.exists(uploadDir)) {
            Files.walk(uploadDir)
                .sorted((p1, p2) -> p2.compareTo(p1)) // Delete children first
                .map(Path::toFile)
                .forEach(File::delete);
        }
    }

    @Test
    void testUploadGetAndDeleteResume() throws Exception {
        // Create a user & job seeker
        User user = new User();
        user.setName("TestUser");
        user.setEmail("testuser@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        JobSeeker js = new JobSeeker();
        js.setUser(user);
        jobSeekerRepository.save(js);

        // Upload resume file
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "resume.pdf",
                "application/pdf",
                "Sample Resume Content".getBytes()
        );

        mockMvc.perform(multipart("/api/resumes/upload")
                        .file(file)
                        .param("jobSeekerId", js.getId().toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.filePath").exists());

        Resume saved = resumeRepository.findByJobSeeker(js).orElseThrow();
        assertThat(saved.getJobSeeker().getId()).isEqualTo(js.getId());
        assertThat(saved.getFilePath()).contains("/uploads/");

        // Check file physically exists
        Path uploadedFile = Path.of(saved.getFilePath().replaceFirst("/", ""));
        assertThat(Files.exists(uploadedFile)).isTrue();

        // Get resume by job seeker ID
        mockMvc.perform(get("/api/resumes/get")
                        .param("jobSeekerId", js.getId().toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.filePath").value(saved.getFilePath()));

        // Delete resume
        mockMvc.perform(delete("/api/resumes/delete")
                        .param("jobSeekerId", js.getId().toString()))
                .andExpect(status().isOk())
                .andExpect(content().string("Resume deleted successfully"));

        assertThat(resumeRepository.findByJobSeeker(js)).isEmpty();
        assertThat(Files.exists(uploadedFile)).isFalse();
    }
}
*/


package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;
import com.career_crafter.job_portal.security.JwtUtil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

import javax.sql.DataSource;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;

import static org.assertj.core.api.Assertions.assertThat;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = "spring.profiles.active=test")
@AutoConfigureMockMvc
class ResumeRestControllerIntegrationTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ResumeRepository resumeRepository;
    @Autowired private JobSeekerRepository jobSeekerRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private DataSource dataSource;

    private String jwtToken;

    @BeforeEach
    void cleanUp() throws Exception {
        // ✅ Debug: show which DB is used
        try (Connection conn = dataSource.getConnection()) {
            System.out.println("### ACTUAL DB URL: " + conn.getMetaData().getURL());
        }

        resumeRepository.deleteAll();
        jobSeekerRepository.deleteAll();
        userRepository.deleteAll();

        // ✅ Create test user & JWT
        User user = new User();
        user.setName("TestUser");
        user.setEmail("testuser@example.com");
        user.setPassword("pass");
        user.setRole("USER");
        userRepository.save(user);

        jwtToken = jwtUtil.generateToken(user);

        // Clear uploads folder
        Path uploadDir = Path.of("uploads");
        if (Files.exists(uploadDir)) {
            Files.walk(uploadDir)
                .sorted((p1, p2) -> p2.compareTo(p1)) // Delete children first
                .map(Path::toFile)
                .forEach(File::delete);
        }
    }

    @Test
    void testUploadGetAndDeleteResume() throws Exception {
        // Get the saved user & make JobSeeker
        User user = userRepository.findByEmail("testuser@example.com").orElseThrow();
        JobSeeker js = new JobSeeker();
        js.setUser(user);
        jobSeekerRepository.save(js);

        // Upload resume file
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "resume.pdf",
                "application/pdf",
                "Sample Resume Content".getBytes()
        );

        mockMvc.perform(multipart("/api/resumes/upload")
                        .file(file)
                        .param("jobSeekerId", js.getId().toString())
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.filePath").exists());

        Resume saved = resumeRepository.findByJobSeeker(js).orElseThrow();
        assertThat(saved.getJobSeeker().getId()).isEqualTo(js.getId());
        assertThat(saved.getFilePath()).contains("/uploads/");

        // Physically verify file exists
        Path uploadedFile = Path.of(saved.getFilePath().replaceFirst("/", ""));
        assertThat(Files.exists(uploadedFile)).isTrue();

        // Get resume
        mockMvc.perform(get("/api/resumes/get")
                        .param("jobSeekerId", js.getId().toString())
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.filePath").value(saved.getFilePath()));

        // Delete resume
        mockMvc.perform(delete("/api/resumes/delete")
                        .param("jobSeekerId", js.getId().toString())
                        .header("Authorization", "Bearer " + jwtToken))
                .andExpect(status().isOk())
                .andExpect(content().string("Resume deleted successfully"));

        assertThat(resumeRepository.findByJobSeeker(js)).isEmpty();
        assertThat(Files.exists(uploadedFile)).isFalse();
    }
}

