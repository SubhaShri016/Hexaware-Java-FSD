package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @Test
    public void testUserRegistration() {
        // Given
        User user = new User();
        user.setName("Test User");
        user.setEmail("testuser@example.com");
        user.setPassword("password123");
        user.setRole("USER");

        // When
        User savedUser = userRepository.save(user);

        // Then
        assertThat(savedUser.getId()).isNotNull();
        assertThat(savedUser.getEmail()).isEqualTo("testuser@example.com");
    }

    @Test
    public void testFindByEmailAndPassword() {
        // Given
        User user = new User();
        user.setName("Login Test");
        user.setEmail("login@example.com");
        user.setPassword("pass123");
        user.setRole("USER");
        userRepository.save(user);

        // When
        User foundUser = userRepository.findByEmailAndPassword("login@example.com", "pass123");

        // Then
        assertThat(foundUser).isNotNull();
        assertThat(foundUser.getName()).isEqualTo("Login Test");
    }
}
