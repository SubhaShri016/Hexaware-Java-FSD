/*package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(locations = "classpath:application-test.properties")
public class UserRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;  // For converting objects to JSON

    @BeforeEach
    void setup() {
        userRepository.deleteAll();  // Clean the DB before each test
    }

    @Test
    void testRegisterUserSuccess() throws Exception {
        // Create a request DTO as JSON
        String requestJson = """
        {
            "name": "John Doe",
            "email": "john@example.com",
            "password": "password123",
            "role": "USER"
        }
        """;

        mockMvc.perform(post("/api/users/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.email").value("john@example.com"))
                .andExpect(jsonPath("$.role").value("USER"));
    }

    @Test
    void testRegisterUserEmailExists() throws Exception {
        // Save a user manually
        User existing = new User();
        existing.setName("Jane");
        existing.setEmail("jane@example.com");
        existing.setPassword("pass");
        existing.setRole("USER");
        userRepository.save(existing);

        // Try to register with same email
        String requestJson = """
        {
            "name": "Jane New",
            "email": "jane@example.com",
            "password": "newpass",
            "role": "USER"
        }
        """;

        mockMvc.perform(post("/api/users/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
                .andExpect(status().isConflict())
                .andExpect(content().string("Email already exists"));
    }

    @Test
    void testLoginSuccess() throws Exception {
        // Save a user
        User user = new User();
        user.setName("Sam");
        user.setEmail("sam@example.com");
        user.setPassword("pass123");
        user.setRole("USER");
        userRepository.save(user);

        String loginJson = """
        {
            "email": "sam@example.com",
            "password": "pass123"
        }
        """;

        mockMvc.perform(post("/api/users/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(loginJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("sam@example.com"))
                .andExpect(jsonPath("$.password").doesNotExist());  // Make sure password is null
    }

    @Test
    void testLoginInvalidCredentials() throws Exception {
        String loginJson = """
        {
            "email": "nonexistent@example.com",
            "password": "wrongpass"
        }
        """;

        mockMvc.perform(post("/api/users/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(loginJson))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string("Invalid credentials"));
    }
}
*/

package com.career_crafter.job_portal;

import com.career_crafter.job_portal.dto.RegisterRequestDto;
import com.career_crafter.job_portal.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// ✅ Real integration test: real JWT, real SecurityConfig, real DB
@SpringBootTest
@AutoConfigureMockMvc
class UserRestControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private String adminJwt;

    @BeforeEach
    void setupAdmin() throws Exception {
        // Ensure an admin user exists
        String adminEmail = "admin@test.com";
        String adminPass = "adminpass";

        if (userRepository.findByEmail(adminEmail).isEmpty()) {
            RegisterRequestDto registerDto = new RegisterRequestDto();
            registerDto.setName("Admin User");
            registerDto.setEmail(adminEmail);
            registerDto.setPassword(adminPass);
            registerDto.setRole("ADMIN");
            registerDto.setCompanyName("Admin Inc");
            registerDto.setLocation("HQ");
            registerDto.setWebsite("https://admin.com");

            mockMvc.perform(post("/api/auth/register")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(registerDto)))
                    .andExpect(status().isOk());
        }

        // Log in to get fresh JWT
        String loginPayload = "{ \"email\": \"" + adminEmail + "\", \"password\": \"" + adminPass + "\" }";

        String response = mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginPayload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").exists())
                .andReturn().getResponse().getContentAsString();

        adminJwt = objectMapper.readTree(response).get("token").asText();
    }

    @Test
    void testRegisterDuplicateEmail_shouldReturnBadRequest() throws Exception {
        RegisterRequestDto duplicate = new RegisterRequestDto();
        duplicate.setName("Admin Again");
        duplicate.setEmail("admin@test.com"); // same as setupAdmin
        duplicate.setPassword("newpass");
        duplicate.setRole("ADMIN");

        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(duplicate)))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(containsString("Email already exists")));
    }

    @Test
    void testLoginAndMe_shouldReturnValidUser() throws Exception {
        String loginPayload = "{ \"email\": \"admin@test.com\", \"password\": \"adminpass\" }";

        String response = mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(loginPayload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").exists())
                .andReturn().getResponse().getContentAsString();

        String jwt = objectMapper.readTree(response).get("token").asText();

        mockMvc.perform(get("/api/auth/me")
                        .header("Authorization", "Bearer " + jwt))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("admin@test.com"));
    }

    @Test
    void testGetAllUsers_withValidJWT_shouldReturnOk() throws Exception {
        mockMvc.perform(get("/api/users") // ✅ your real endpoint
                        .header("Authorization", "Bearer " + adminJwt))
                .andExpect(status().isOk());
    }

    @Test
    void testGetAllUsers_withoutJWT_shouldBeForbidden() throws Exception {
        mockMvc.perform(get("/api/users"))
                .andExpect(status().isForbidden());
    }
}
