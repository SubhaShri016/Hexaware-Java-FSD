package com.career_crafter.job_portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.UserRepository;

@Controller
public class MainController {

    @Autowired
    private UserRepository userRepository;

    // Home page
    @GetMapping("/")
    public String index() {
        return "forward:/index.jsp";
    }

    // Login page
    @GetMapping("/login")
    public String loginPage() {
        return "forward:/loginpage.jsp";
    }

    // Register page
    @GetMapping("/register")
    public String registerPage() {
        return "forward:/registerpage.jsp";
    }

    // Admin home page
    @GetMapping("/admin/home")
    public String adminHome() {
        return "forward:/adminhome.jsp";
    }

    // User home page
    @GetMapping("/user/home")
    public String userHome() {
        return "forward:/userhome.jsp";
    }

    // Employer home page
    @GetMapping("/employer/home")
    public String employerHome() {
        return "forward:/employerhome.jsp";
    }

    // Handle Registration
    @PostMapping("/register")
    public String registerUser(@RequestParam String name,
                               @RequestParam String email,
                               @RequestParam String password,
                               @RequestParam String role,
                               Model model) {

        if (userRepository.existsByEmail(email)) {
            model.addAttribute("message", "Email already registered!");
            return "forward:/registerpage.jsp";
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);

        userRepository.save(user);
        model.addAttribute("message", "Registration successful! Please login.");
        return "redirect:/loginpage.jsp";
    }

    // Handle Login
    @PostMapping("/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            Model model) {

        User user = userRepository.findByEmailAndPassword(email, password);
        if (user == null) {
            model.addAttribute("message", "Invalid credentials!");
            return "redirect:/loginpage.jsp";
        }

        String role = user.getRole();
        if (role.equalsIgnoreCase("admin")) {
            return "redirect:/adminhome.jsp";
        } else if (role.equalsIgnoreCase("employer")) {
            return "redirect:/employerhome.jsp";
        } else {
            return "redirect:/userhome.jsp";
        }
    }
}
