package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/jobseeker")
public class JobSeekerController {

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    // 👉 1. Show profile creation form
    @GetMapping("/profile")
    public String profileForm(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");

        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        JobSeeker jobSeeker = jobSeekerRepository.findById(user.getId()).orElse(null);
        model.addAttribute("jobSeeker", jobSeeker);
        return "forward:/jobseeker_profile.jsp";
    }

    // 👉 2. Save or update profile
    @PostMapping("/profile/save")
    public String saveProfile(@RequestParam String education,
                              @RequestParam String experience,
                              @RequestParam String skills,
                              HttpSession session,
                              Model model) {

        User user = (User) session.getAttribute("user");

        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        JobSeeker jobSeeker = jobSeekerRepository.findById(user.getId()).orElse(null);
        if (jobSeeker == null) {
            jobSeeker = new JobSeeker();
            jobSeeker.setUser(user);
        }

        jobSeeker.setEducation(education);
        jobSeeker.setExperience(experience);
        jobSeeker.setSkills(skills);

        jobSeekerRepository.save(jobSeeker);

        model.addAttribute("message", "Profile updated successfully!");
        model.addAttribute("jobSeeker", jobSeeker);
        return "forward:/jobseeker_profile.jsp";
    }

    // 👉 3. View all jobs
    @GetMapping("/jobs")
    public String viewAllJobs(Model model) {
        List<Job> jobs = jobRepository.findAll();
        model.addAttribute("jobs", jobs);
        return "forward:/job_list.jsp";
    }

    // 👉 4. Show resume upload form
    @GetMapping("/resume")
    public String showResumeUploadForm(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        JobSeeker jobSeeker = jobSeekerRepository.findById(user.getId()).orElse(null);
        if (jobSeeker == null) {
            model.addAttribute("message", "Please create your job seeker profile first.");
            return "forward:/jobseeker_profile.jsp";
        }

        Resume resume = resumeRepository.findByJobSeeker(jobSeeker);
        model.addAttribute("resume", resume);
        return "forward:/resume_upload.jsp";
    }

    // 👉 5. Upload resume file
    @PostMapping("/resume/upload")
    public String uploadResume(@RequestParam("file") MultipartFile file,
                               HttpSession session,
                               Model model) {

        User user = (User) session.getAttribute("user");
        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        JobSeeker jobSeeker = jobSeekerRepository.findById(user.getId()).orElse(null);
        if (jobSeeker == null) {
            model.addAttribute("message", "Please create your profile before uploading a resume.");
            return "forward:/jobseeker_profile.jsp";
        }

        if (file.isEmpty()) {
            model.addAttribute("message", "Please choose a file to upload.");
            return "forward:/resume_upload.jsp";
        }

        try {
            // Create upload directory if it doesn't exist
            String uploadDir = "uploads/resumes/";
            File dir = new File(uploadDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            // Unique file name
            String fileName = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
            String filePath = uploadDir + fileName;

            // Save the file to the disk
            file.transferTo(new File(filePath));

            // Save resume metadata to DB
            Resume resume = resumeRepository.findByJobSeeker(jobSeeker);
            if (resume == null) {
                resume = new Resume();
                resume.setJobSeeker(jobSeeker);
            }

            resume.setFilePath(filePath);
            resumeRepository.save(resume);

            model.addAttribute("message", "Resume uploaded successfully!");
            model.addAttribute("resume", resume);
        } catch (IOException e) {
            e.printStackTrace();
            model.addAttribute("message", "Error uploading resume.");
        }

        return "forward:/resume_upload.jsp";
    }

    // 👉 6. Apply for a job
    @PostMapping("/apply")
    public String applyForJob(@RequestParam Long jobId, HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");

        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        JobSeeker jobSeeker = jobSeekerRepository.findById(user.getId()).orElse(null);
        if (jobSeeker == null) {
            model.addAttribute("message", "Please create your job seeker profile first.");
            return "forward:/jobseeker_profile.jsp";
        }

        Job job = jobRepository.findById(jobId).orElse(null);
        if (job == null) {
            model.addAttribute("message", "Job not found.");
            return "forward:/job_list.jsp";
        }

        Application application = new Application();
        application.setJob(job);
        application.setJobSeeker(jobSeeker);
        application.setStatus("Applied");

        applicationRepository.save(application);

        model.addAttribute("message", "Application submitted successfully!");
        return "redirect:/jobseeker/jobs";
    }
    
 // 👉 7. View applications for the logged-in job seeker
    @GetMapping("/applications")
    public String viewApplications(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");

        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        JobSeeker jobSeeker = jobSeekerRepository.findById(user.getId()).orElse(null);
        if (jobSeeker == null) {
            model.addAttribute("message", "Please create your job seeker profile first.");
            return "forward:/jobseeker_profile.jsp";
        }

        List<Application> applications = applicationRepository.findByJobSeeker(jobSeeker);
        model.addAttribute("applications", applications);
        return "forward:/jobseeker_applications.jsp";
    }


    // 👉 7. Action to track applications (optional - coming next if needed)
}
