package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/jobseekers")
public class JobSeekerRestController {

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @GetMapping
    public List<JobSeeker> getAllJobSeekers() {
        return jobSeekerRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<JobSeeker> getJobSeekerById(@PathVariable Long id) {
        return jobSeekerRepository.findById(id);
    }

    @PostMapping
    public JobSeeker createJobSeeker(@RequestBody JobSeeker jobSeeker) {
        return jobSeekerRepository.save(jobSeeker);
    }

    @PutMapping("/{id}")
    public JobSeeker updateJobSeeker(@PathVariable Long id, @RequestBody JobSeeker updatedJobSeeker) {
        updatedJobSeeker.setId(id);
        return jobSeekerRepository.save(updatedJobSeeker);
    }

    @DeleteMapping("/{id}")
    public void deleteJobSeeker(@PathVariable Long id) {
        jobSeekerRepository.deleteById(id);
    }
}
