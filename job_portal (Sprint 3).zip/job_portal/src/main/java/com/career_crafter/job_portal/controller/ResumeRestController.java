package com.career_crafter.job_portal.controller;

import com.career_crafter.job_portal.entity.Resume;
import com.career_crafter.job_portal.repository.ResumeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/resumes")
public class ResumeRestController {

    @Autowired
    private ResumeRepository resumeRepository;

    @GetMapping
    public List<Resume> getAllResumes() {
        return resumeRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Resume> getResumeById(@PathVariable Long id) {
        return resumeRepository.findById(id);
    }

    @PostMapping
    public Resume createResume(@RequestBody Resume resume) {
        return resumeRepository.save(resume);
    }

    @PutMapping("/{id}")
    public Resume updateResume(@PathVariable Long id, @RequestBody Resume updatedResume) {
        updatedResume.setId(id);
        return resumeRepository.save(updatedResume);
    }

    @DeleteMapping("/{id}")
    public void deleteResume(@PathVariable Long id) {
        resumeRepository.deleteById(id);
    }
}
