package com.career_crafter.job_portal.repository;

import com.career_crafter.job_portal.entity.JobSeeker;


import org.springframework.data.jpa.repository.JpaRepository;

public interface JobSeekerRepository extends JpaRepository<JobSeeker, Long> {
	

}
