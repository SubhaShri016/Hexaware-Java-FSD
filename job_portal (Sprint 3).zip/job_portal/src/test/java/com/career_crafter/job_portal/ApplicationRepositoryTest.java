package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.*;
import com.career_crafter.job_portal.repository.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ApplicationRepositoryTest {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Test
    public void testSaveApplication() {
        JobSeeker seeker = new JobSeeker();
        seeker.setEducation("MCA");
        seeker.setExperience("1 year");
        seeker.setSkills("Python");
        jobSeekerRepository.save(seeker);

        Job job = new Job();
        job.setTitle("Python Dev");
        job.setDescription("Django Developer");
        job.setLocation("Remote");
        job.setQualifications("MCA");
        jobRepository.save(job);

        Application app = new Application();
        app.setJob(job);
        app.setJobSeeker(seeker);
        app.setResumePath("resume.pdf");
        app.setStatus("Pending");

        Application savedApp = applicationRepository.save(app);

        assertThat(savedApp.getId()).isNotNull();
        assertThat(savedApp.getStatus()).isEqualTo("Pending");
    }
}
