package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.Job;
import com.career_crafter.job_portal.entity.Employer;
import com.career_crafter.job_portal.repository.JobRepository;
import com.career_crafter.job_portal.repository.EmployerRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class JobRepositoryTest {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private EmployerRepository employerRepository;

    @Test
    public void testSaveJob() {
        Employer employer = new Employer();
        employer.setCompanyName("TestCorp");
        employer.setLocation("Hyderabad");
        employer.setWebsite("https://testcorp.com");
        employerRepository.save(employer);

        Job job = new Job();
        job.setEmployer(employer);
        job.setTitle("Java Developer");
        job.setDescription("Backend development with Spring Boot");
        job.setLocation("Remote");
        job.setQualifications("B.Tech CSE");

        Job savedJob = jobRepository.save(job);

        assertThat(savedJob.getId()).isNotNull();
        assertThat(savedJob.getTitle()).isEqualTo("Java Developer");
    }
}
