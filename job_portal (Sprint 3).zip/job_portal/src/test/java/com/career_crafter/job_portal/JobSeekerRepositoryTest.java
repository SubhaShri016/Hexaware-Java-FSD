package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.User;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.UserRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class JobSeekerRepositoryTest {

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Autowired
    private UserRepository userRepository;

    @Test
    public void testSaveJobSeeker() {
        User user = new User();
        user.setName("Ravi Kumar");
        user.setEmail("ravi@example.com");
        user.setPassword("1234");
        user.setRole("USER");
        userRepository.save(user);

        JobSeeker seeker = new JobSeeker();
        seeker.setUser(user);
        seeker.setEducation("B.Tech CSE");
        seeker.setExperience("2 years");
        seeker.setSkills("Java, Spring Boot");

        JobSeeker savedSeeker = jobSeekerRepository.save(seeker);

        assertThat(savedSeeker.getId()).isNotNull();
        assertThat(savedSeeker.getSkills()).contains("Spring");
    }
}
