package com.career_crafter.job_portal;

import com.career_crafter.job_portal.entity.JobSeeker;
import com.career_crafter.job_portal.entity.Resume;
import com.career_crafter.job_portal.repository.JobSeekerRepository;
import com.career_crafter.job_portal.repository.ResumeRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ResumeRepositoryTest {

    @Autowired
    private ResumeRepository resumeRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Test
    public void testSaveResume() {
        JobSeeker seeker = new JobSeeker();
        seeker.setEducation("MBA");
        seeker.setExperience("3 years");
        seeker.setSkills("Management");
        jobSeekerRepository.save(seeker);

        Resume resume = new Resume();
        resume.setJobSeeker(seeker);
        resume.setFilePath("mba_resume.pdf");

        Resume savedResume = resumeRepository.save(resume);

        assertThat(savedResume.getId()).isNotNull();
        assertThat(savedResume.getFilePath()).isEqualTo("mba_resume.pdf");
    }
}
